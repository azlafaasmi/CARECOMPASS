<?php
require_once('./Connection.php');
session_start();

// Check database connection
if (!$conp) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $bill_id = $_POST['bill_id'];
    $patient_id = $_POST['patient_id'];
    $appointment_id = $_POST['appointment_id'];
    $total_amount = $_POST['total_amount'];
    $payment_date = $_POST['payment_date'];
    $payment_method = $_POST['payment_method'];
    $payment_status = $_POST['payment_status'];

    // Validate required fields
    if (!empty($bill_id) && !empty($patient_id) && !empty($appointment_id) && !empty($total_amount) 
        && !empty($payment_date) && !empty($payment_method) && !empty($payment_status)) {

        // Use prepared statement to prevent SQL injection
        $query = "INSERT INTO billing (bill_id, patient_id, appointment_id, total_amount, payment_date, payment_method, payment_status) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($conp, $query)) {
            // Binding parameters correctly
            mysqli_stmt_bind_param($stmt, "iiidsss", $bill_id, $patient_id, $appointment_id, $total_amount, $payment_date, $payment_method, $payment_status);

            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['message'] = "Payment details added successfully!";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Error adding payment details: " . mysqli_stmt_error($stmt);
                $_SESSION['message_type'] = "error";
            }

            mysqli_stmt_close($stmt);
        } else {
            $_SESSION['message'] = "Database error: Unable to prepare statement.";
            $_SESSION['message_type'] = "error";
        }
    } else {
        $_SESSION['message'] = "All fields are required!";
        $_SESSION['message_type'] = "error";
    }

    // Redirect back to form page
    header("Location: addingPayment.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('./src/background.avif');
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }
        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }
        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border: 2px solid black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: black;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            font-weight: bold;
            color: black;
        }
        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid black;
            border-radius: 5px;
        }
        button {
            background-color: rgb(126, 126, 126);
            color: black;
            padding: 12px 20px;
            border: 1px solid black;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: rgb(7, 7, 7);
            color: white;
        }
        .message {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <header>
        <h1>Payment Details</h1>
    </header>

    <div class="container">
        <form action="addingPayment.php" method="POST">
            <h2>Add Payment Details</h2>

            <!-- Display Success or Error Message -->
            <?php if (isset($_SESSION['message'])): ?>
                <div class="message <?php echo $_SESSION['message_type']; ?>">
                    <?php 
                        echo $_SESSION['message']; 
                        unset($_SESSION['message']); 
                        unset($_SESSION['message_type']); 
                    ?>
                </div>
            <?php endif; ?>

            <label for="bill_id">Bill ID</label>
            <input type="number" id="bill_id" name="bill_id" required>

            <label for="patient_id">Patient ID</label>
            <input type="text" id="patient_id" name="patient_id" required>

            <label for="appointment_id">Appointment ID</label>
            <input type="number" id="appointment_id" name="appointment_id" required>

            <label for="total_amount">Total Amount</label>
            <input type="number" id="total_amount" name="total_amount" required>

            <label for="payment_date">Payment Date</label>
            <input type="date" id="payment_date" name="payment_date" required>

            <label for="payment_method">Payment Method</label>
            <select id="payment_method" name="payment_method" required>
                <option value="Cash">Cash</option>
                <option value="Credit Card">Credit Card</option>
                <option value="Debit Card">Debit Card</option>
                <option value="Online">Online</option>
            </select>

            <label for="payment_status">Payment Status</label>
            <select id="payment_status" name="payment_status" required>
                <option value="Paid">Paid</option>
                <option value="Pending">Pending</option>
                <option value="Failed">Failed</option>
            </select>

            <button type="submit" name="submit">Submit Payment</button>
        </form>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>
