<?php
require_once('./Connection.php'); // Ensure the database connection is properly established
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Payment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('./src/background.avif') ;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }

        table {
            width: 90%;
            color: black;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: rbg(255, 255, 255, 0.8);
        }

        table, th, td {
            border: 1px solid black;

        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
        }

        tr:nth-child(even) {
            background-color: rbg(240, 240, 240, 0.7);
        }

        button {
            background-color: rgb(119, 122, 119);
            color: white;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
        }

        button:hover {
            background-color: rgb(5, 5, 5);
        }
    </style>
</head>
<body>

<header>
    <h1>Billing Details</h1>
</header>

<main>
    <table>
        <thead>
            <tr>
                <th>Bill ID</th>
                <th>Patient ID</th>
                <th>Appointment ID</th>
                <th>Total Amount</th>
                <th>Payment Date</th>
                <th>Payment Method</th>
                <th>Payment Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Query to fetch billing details
            $query = "SELECT bill_id, patient_id, appointment_id, total_amount, payment_date, payment_method, payment_status FROM billing";
            $result = mysqli_query($conp, $query);

            // Check if the query executed successfully
            if (!$result) {
                die("Database query failed: " . mysqli_error($conp));
            }

            // Fetch and display each row of billing data
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['bill_id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['patient_id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['appointment_id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['total_amount']) . "</td>";
                echo "<td>" . htmlspecialchars($row['payment_date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['payment_method']) . "</td>";
                echo "<td>" . htmlspecialchars($row['payment_status']) . "</td>";
                echo "<td><a href='./billingUpdate.php?bill_id=" . $row['bill_id'] . "'><button>Update</button></a></td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</main>

<footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>

</body>
</html>
