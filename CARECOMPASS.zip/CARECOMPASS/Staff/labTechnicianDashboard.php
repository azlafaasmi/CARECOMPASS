<?php
session_start();
require_once('../Connection.php'); // Ensure the database connection is included

// Check if user is logged in and is a Lab Technician
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'Lab Technician') {
    echo "<script>alert('Access denied! Please login as a Lab Technician.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}

// Get the logged-in lab technician's name
$user_name = $_SESSION['username'] ?? null; // Ensure this matches your session variable

if ($user_name) {
    // Fetch lab technician data based on the username
    $query = "SELECT * FROM staff WHERE full_name = '$user_name'";
    $result = mysqli_query($conp, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $technician = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Error fetching technician details or no records found.');</script>";
        exit();
    }
} else {
    echo "<script>alert('No technician session found. Please log in again.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Technician Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(83, 82, 82);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background-color: rgba(92, 92, 93, 0.9);
            color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2rem;
        }

        .user-info {
            margin-top: 10px;
            font-size: 1.2rem;
            font-weight: bold;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.95);
            padding: 50px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            border: 5px solid gray;
        }

        nav {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }

        nav a {
            text-decoration: none;
            font-size: 1rem;
            color: white;
            background-color: rgb(114, 117, 119);
            padding: 12px 25px;
            border-radius: 25px;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        nav a:hover {
            background-color: rgb(0, 1, 1);
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
            transform: translateY(-2px);
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(89, 90, 91, 0.9);
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.2);
        }

        footer h3 {
            margin: 0;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <header>
        <h1>Lab Technician Dashboard</h1>
        <p class="user-info">Welcome, <?php echo htmlspecialchars($technician['full_name'] ?? 'Technician'); ?> !</p>
    </header>

    <div class="container">
        <nav>
            <a href="../laboratoryReports.php">View and Update Test Results</a>
            <a href="../Users/Logout.php">Logout</a>
        </nav>  
    </div>

    <footer>
        <h3>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</h3>
    </footer>
</body>
</html>
