<?php
session_start();
require_once('../Connection.php'); // Ensure the database connection is included

// Check if user is logged in and is a Doctor
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'Doctor') {
    echo "<script>alert('Access denied! Please login as a Doctor.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}

// Get the logged-in doctor's username
$doctor_name = $_SESSION['username'] ?? null;

if ($doctor_name) {
    // Prepare and execute the query to fetch appointments for the logged-in doctor
    $stmt = $conp->prepare("SELECT appointment_id, patient_id, appointment_time, appointment_date, status FROM appointments WHERE doctor_name = ?");
    if (!$stmt) {
        die("SQL error: " . htmlspecialchars($conp->error)); // Display any SQL errors
    }

    $stmt->bind_param("s", $doctor_name);
    if (!$stmt->execute()) {
        die("Execution error: " . htmlspecialchars($stmt->error)); // Display execution errors
    }

    $result = $stmt->get_result();

    // Fetch appointments and store in an array
    $appointments = [];
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
} else {
    echo "<script>alert('No doctor session found. Please log in again.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor's Appointments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(83, 82, 82);
            margin: 0;
            padding: 0;
        }
        header {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background-color: rgba(92, 92, 93, 0.9);
            color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.95);
            padding: 50px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            border: 5px solid gray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid gray;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: rgba(92, 92, 93, 0.8);
            color: white;
        }
        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(89, 90, 91, 0.9);
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <header>
        <h1>Your Appointments</h1>
    </header>

    <div class="container">
        <?php if (!empty($appointments)): ?>
            <table>
                <tr>
                    <th>Appointment ID</th>
                    <th>Patient ID</th>
                    <th>Appointment Date</th>
                    <th>Appointment Time</th>
                    <th>Status</th>
                </tr>
                <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($appointment['appointment_id']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['patient_id']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['appointment_date']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['appointment_time']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['status']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>No appointments found.</p>
        <?php endif; ?>
    </div>

    <footer>
        <h3>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</h3>
    </footer>
</body>
</html>
