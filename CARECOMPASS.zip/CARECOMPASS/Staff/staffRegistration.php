<?php
// Start the session and include the database connection
session_start();
require_once('../Connection.php'); // Ensure the database connection file is correctly included

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Sanitize input data
    $staff_id = uniqid('STAFF'); // Auto-generate a unique staff ID
    $user_id = uniqid('USER'); // Auto-generate a unique user ID
    $nic = mysqli_real_escape_string($conp, $_POST['nic']);
    $full_name = mysqli_real_escape_string($conp, $_POST['full_name']);
    $speciality = mysqli_real_escape_string($conp, $_POST['speciality']);
    $qualifications = mysqli_real_escape_string($conp, $_POST['qualifications']);
    $role = mysqli_real_escape_string($conp, $_POST['role']);
    $years_of_experience = mysqli_real_escape_string($conp, $_POST['years_of_experience']);
    $isAvailable = isset($_POST['isAvailable']) ? 1 : 0; // Checkbox for availability
    $email = mysqli_real_escape_string($conp, $_POST['email']);
    $cont_no = mysqli_real_escape_string($conp, $_POST['cont_no']);
    $password = mysqli_real_escape_string($conp, $_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password

    // SQL query to insert the staff data into the database
    $staff_query = "INSERT INTO staff (staff_id, NIC, full_name, speciality, qualifications, role, years_of_experience, isAvailable, email, cont_no, password) 
                    VALUES ('$staff_id', '$nic', '$full_name', '$speciality', '$qualifications', '$role', '$years_of_experience', '$isAvailable', '$email', '$cont_no', '$hashed_password')";

    // Execute the staff insertion query
    if (mysqli_query($conp, $staff_query)) {
        // SQL query to insert the user data into the users table
        $user_query = "INSERT INTO users (user_id, user_name, user_password, role) 
                       VALUES ('$user_id', '$full_name','$hashed_password', '$role')";  

        // Execute the user insertion query
        if (mysqli_query($conp, $user_query)) {
            // On successful insertion into both tables, show a success message and redirect
            echo "<script>
                    alert('Staff registered successfully and added to users table!');
                    window.location.href = '../Users/Login.php';
                  </script>";
            exit(); // Ensure no further script execution after the redirect
        } else {
            // If there is an error in the users table insertion, rollback the staff insertion
            $delete_staff_query = "DELETE FROM staff WHERE staff_id = '$staff_id'";
            mysqli_query($conp, $delete_staff_query); // Rollback staff data
            echo "<script>alert('Error adding staff to users table: " . mysqli_error($conp) . "');</script>";
        }
    } else {
        // If there is an error in the staff insertion
        echo "<script>alert('Error registering staff: " . mysqli_error($conp) . "');</script>";
    }

    // Close the database connection
    mysqli_close($conp);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border: 2px solid black;
            color:black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid black;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .submit-btn {
            width: 100%;
            padding: 10px;
            background-color: rgb(112, 112, 114);
            color: black;
            border: black;
            border-radius: 4px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: rgb(7, 7, 7);
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<header>
    <h1>Welcome to the Staff Dashboard</h1>
</header>

<div class="container">
    <h2>Register New Staff</h2>
    <form action="staffRegistration.php" method="POST">
        <label for="nic">NIC</label>
        <input type="text" id="nic" name="nic" required>

        <label for="full_name">Full Name</label>
        <input type="text" id="full_name" name="full_name" required>

        <label for="speciality">Speciality</label>
        <input type="text" id="speciality" name="speciality" required>

        <label for="qualifications">Qualifications</label>
        <input type="text" id="qualifications" name="qualifications" required>

        <label for="role">Role</label>
        <select id="role" name="role" required>
            <option value="Doctor">Doctor</option>
            <option value="Nurse">Nurse</option>
            <option value="Receptionist">Receptionist</option>
            <option value="Technician">Lab Technician</option>
        </select>

        <label for="years_of_experience">Years of Experience</label>
        <input type="number" id="years_of_experience" name="years_of_experience" min="0" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>

        <label for="cont_no">Contact Number</label>
        <input type="tel" id="cont_no" name="cont_no" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        
        <label for="isAvailable">Available</label>
        <input type="checkbox" id="isAvailable" name="isAvailable">


        <button type="submit" name="submit" class="submit-btn">Register</button>
    </form>
</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
</footer>

</body>
</html>
