<?php
session_start();
require_once('../Connection.php'); // Ensure the database connection is included

// Fetch all doctors from the staff table where role is 'doctor'
$sql = "SELECT staff_id AS doctor_id, NIC, full_name AS doctor_name, speciality, qualifications, cont_no, email, years_of_experience, isAvailable 
        FROM staff WHERE role = 'doctor'";

$result = $conp->query($sql);

$doctors = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $doctors[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            margin: 0;
            padding: 0;
            width: 100%;
        }

        header {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background-color: rgba(92, 92, 93, 0.9);
            color: black;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        footer {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background-color: rgba(92, 92, 93, 0.9);
            color: black;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            text-align: center;
            font-weight: bold;
        }

        .container {
            width: 90%;
            margin: 50px auto;
            background: rbg(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border: 2px solid black;
        }

        #search-bar {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 2px solid gray;
            border-radius: 5px;
            font-size: 16px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            background: rbg(255, 255, 255, 0.98);
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background: rgb(100, 100, 100);
            color: white;
        }

        tr:nth-child(even) {
            background: rgb(220, 220, 220);
        }

        tr:hover {
            background: rgb(200, 200, 200);
        }
    </style>
</head>
<body>
    <header>
        <h1>Doctors List</h1>
    </header>
    <div class="container">
        <!-- Search Bar -->
        <input type="text" id="search-bar" onkeyup="filterDoctors()" placeholder="Search by Name, Specialty, or NIC...">

        <table id="doctors-table">
            <thead>
                <tr>
                    <th>Doctor ID</th>
                    <th>NIC</th>
                    <th>Name</th>
                    <th>Speciality</th>
                    <th>Qualifications</th>
                    <th>Contact Number</th>
                    <th>Email</th>
                    <th>Experience (Years)</th>
                    <th>Available</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($doctors) > 0): ?>
                    <?php foreach ($doctors as $doctor): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($doctor['doctor_id']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['NIC']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['doctor_name']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['speciality']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['qualifications']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['cont_no']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['email']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['years_of_experience']); ?></td>
                            <td><?php echo $doctor['isAvailable'] ? 'Yes' : 'No'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" style="text-align: center; font-weight: bold;">No doctors found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>

    <script>
        function filterDoctors() {
            let input = document.getElementById('search-bar').value.toLowerCase();
            let table = document.getElementById('doctors-table');
            let rows = table.getElementsByTagName('tr');

            for (let i = 1; i < rows.length; i++) {
                let cells = rows[i].getElementsByTagName('td');
                let match = false;

                for (let j = 1; j < 4; j++) { // Checking NIC, Name, and Speciality
                    if (cells[j]) {
                        let textValue = cells[j].textContent || cells[j].innerText;
                        if (textValue.toLowerCase().indexOf(input) > -1) {
                            match = true;
                            break;
                        }
                    }
                }

                rows[i].style.display = match ? "" : "none";
            }
        }
    </script>

</body>
</html>
