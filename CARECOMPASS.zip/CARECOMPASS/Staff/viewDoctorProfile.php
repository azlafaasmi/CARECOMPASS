<?php
session_start();
require_once('../Connection.php'); // Ensure the database connection is included

// Check if user is logged in and is a Doctor
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'Doctor') {
    echo "<script>alert('Access denied! Please login as a Doctor.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}

// Get the logged-in doctor's username
$doctor_name = $_SESSION['username'] ?? null;

if ($doctor_name) {
    // Prepare and execute the query to fetch the doctor's profile
    $stmt = $conp->prepare("SELECT full_name, speciality, cont_no, NIC, email, years_of_experience, staff_id FROM staff WHERE full_name = ?");
    $stmt->bind_param("s", $doctor_name); // Bind the parameter
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the query executed successfully
    if (!$result) {
        echo "Error in query: " . $stmt->error; // Print query error
        exit();
    }

    // Fetch the doctor's profile data
    $doctor_profile = $result->fetch_assoc();
} else {
    echo "<script>alert('No doctor session found. Please log in again.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(83, 82, 82);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background-color: rgba(92, 92, 93, 0.9);
            color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2rem;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.95);
            padding: 50px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            border: 5px solid gray;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid gray;
            padding: 12px;
            text-align: left;
            transition: background-color 0.3s;
        }

        th {
            background-color: rgba(92, 92, 93, 0.8);
            color: white;
            font-weight: bold;
        }

        tr:hover td {
            background-color: rgba(220, 220, 220, 0.7);
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(89, 90, 91, 0.9);
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.2);
        }

        footer h3 {
            margin: 0;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <header>
        <h1>Your Doctor Profile</h1>
    </header>

    <div class="container">
        <?php if ($doctor_profile): ?>
            <table>
                <tr>
                    <th>Full Name</th>
                    <td><?php echo htmlspecialchars($doctor_profile['full_name']); ?></td>
                </tr>
                <tr>
                    <th>Specialization</th>
                    <td><?php echo htmlspecialchars($doctor_profile['speciality']); ?></td>
                </tr>
                <tr>
                    <th>Contact Information</th>
                    <td><?php echo htmlspecialchars($doctor_profile['cont_no']); ?></td>
                </tr>
                <tr>
                    <th>NIC</th>
                    <td><?php echo htmlspecialchars($doctor_profile['NIC']); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo htmlspecialchars($doctor_profile['email']); ?></td>
                </tr>
                <tr>
                    <th>Years of Experience</th>
                    <td><?php echo htmlspecialchars($doctor_profile['years_of_experience']); ?></td>
                </tr>
                <tr>
                    <th>Staff ID</th>
                    <td><?php echo htmlspecialchars($doctor_profile['staff_id']); ?></td>
                </tr>
            </table>
        <?php else: ?>
            <p>No profile information found for you.</p>
        <?php endif; ?>
    </div>

    <footer>
        <h3>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</h3>
    </footer>
</body>
</html>
