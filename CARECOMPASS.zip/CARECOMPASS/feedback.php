<?php
session_start();
require_once('./Connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize it
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $feedback = htmlspecialchars(trim($_POST['feedback']));

    // Get the current date and time
    $created_at = date("Y-m-d H:i:s");

    // Simple validation
    if (!empty($name) && !empty($email) && !empty($feedback) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Prepare the SQL query using prepared statements to prevent SQL injection
        $sql = "INSERT INTO feedback (name, email, feedback, created_at) VALUES (?, ?, ?, ?)";
        if ($stmt = mysqli_prepare($conp, $sql)) {
            // Bind the parameters to the query
            mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $feedback, $created_at);

            // Execute the query
            if (mysqli_stmt_execute($stmt)) {
                $message = "Feedback submitted successfully!";
            } else {
                $message = "Error submitting feedback: " . mysqli_error($conp);
            }
            mysqli_stmt_close($stmt);
        } else {
            $message = "Database error: Could not prepare the statement.";
        }
    } else {
        $message = "Please fill in all fields and ensure the email is valid.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('./src/background.avif');
            background-size: cover;
            color: #333;
            margin: 0;
            padding: 0;
        }
        
        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            font-weight: bold;
        }

        .container {
            max-width: 600px;
            margin: 80px auto;
            background: rbg(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: 2px solid gray;
        }
        h1 {
            color: black;
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            background: rbg(255, 255, 255, 0.9);
            border: 1px solid gray;
        }
        .form-group textarea {
            height: 150px;
            resize: vertical;
        }
        .form-group button {
            background-color:rgb(122, 125, 122);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color:rgb(5, 5, 5);
        }
        .message {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color:rgb(24, 143, 32);
        }
        
        footer {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to CARECOMPASS Hospital Feedback</h1>
    </header>

    <div class="container">
        <h1>Feedback Form</h1>
        <?php if (isset($message)) { echo "<div class='message'>$message</div>"; } ?>
        <form method="POST" action="feedback.php">
            <div class="form-group">
                <label for="name">Your Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Your Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="feedback">Your Feedback:</label>
                <textarea id="feedback" name="feedback" required></textarea>
            </div>
            <div class="form-group">
                <button type="submit">Submit Feedback</button>
            </div>
        </form>
    </div>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>

</body>
</html>
