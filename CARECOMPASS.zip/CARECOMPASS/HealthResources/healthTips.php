<?php
// healthTips.php

class HealthTip {
    private $title;
    private $description;

    // Constructor to initialize the health tip details
    public function __construct($title, $description) {
        $this->title = $title;
        $this->description = $description;
    }

    // Getters and setters for each property
    public function getTitle() {
        return $this->title;
    }

    public function setTitle($title) {
        $this->title = $title;
    }

    public function getDescription() {
        return $this->description;
    }

    public function setDescription($description) {
        $this->description = $description;
    }

    // Method to return the tip details as an array
    public function toArray() {
        return [
            'title' => $this->title,
            'description' => $this->description
        ];
    }
}

class HealthTipManager {
    private $tips = [];

    // Method to add a new health tip
    public function addTip(HealthTip $tip) {
        $this->tips[] = $tip;
    }

    // Method to get all health tips
    public function getTips() {
        return $this->tips;
    }

    // Method to display all health tips
    public function displayTips() {
        echo "<table border='1'><tr><th>Title</th><th>Description</th></tr>";
        foreach ($this->tips as $tip) {
            $tipDetails = $tip->toArray();
            echo "<tr><td>{$tipDetails['title']}</td><td>{$tipDetails['description']}</td></tr>";
        }
        echo "</table>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Tips</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            color: black;
            border: 3px solid black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            color: black;
        }

        table, th, td {
            border: 2px solid black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #ccc;
        }

    </style>
</head>
<body>

<header>
    <h1>Health Tips</h1>
</header>

<div class="container">
    <?php
    // Example usage
    $healthTipManager = new HealthTipManager();

    // Adding health tips
    $healthTipManager->addTip(new HealthTip("Stay Hydrated", "Drink at least 8 glasses of water daily to maintain proper hydration."));
    $healthTipManager->addTip(new HealthTip("Exercise Regularly", "Aim for at least 30 minutes of exercise most days of the week."));
    $healthTipManager->addTip(new HealthTip("Get Enough Sleep", "Ensure you get 7-9 hours of sleep every night to improve overall health."));
    $healthTipManager->addTip(new HealthTip("Eat a Balanced Diet", "Include a variety of fruits, vegetables, whole grains, and proteins in your meals."));
    $healthTipManager->addTip(new HealthTip("Limit Sugar Intake", "Avoid excessive sugar consumption to reduce the risk of chronic diseases."));
    $healthTipManager->addTip(new HealthTip("Reduce Stress", "Practice relaxation techniques like meditation or deep breathing to manage stress."));
    $healthTipManager->addTip(new HealthTip("Avoid Smoking", "Quit smoking to improve lung health and reduce the risk of cancer."));
    $healthTipManager->addTip(new HealthTip("Limit Alcohol Consumption", "Drink alcohol in moderation, if at all, to protect your liver and overall health."));
    $healthTipManager->addTip(new HealthTip("Practice Good Hygiene", "Wash your hands frequently to avoid infections."));
    $healthTipManager->addTip(new HealthTip("Regular Check-ups", "Visit your healthcare provider regularly for preventive screenings."));
    $healthTipManager->addTip(new HealthTip("Use Sunscreen", "Protect your skin from harmful UV rays by using sunscreen regularly."));
    $healthTipManager->addTip(new HealthTip("Stay Active", "Engage in physical activities that you enjoy to maintain a healthy lifestyle."));
    $healthTipManager->addTip(new HealthTip("Maintain a Healthy Weight", "Achieve and maintain a healthy weight through a balanced diet and exercise."));
    $healthTipManager->addTip(new HealthTip("Limit Processed Foods", "Eat whole, unprocessed foods to nourish your body effectively."));
    $healthTipManager->addTip(new HealthTip("Avoid Excessive Caffeine", "Limit caffeine consumption to avoid negative effects like anxiety or insomnia."));
    $healthTipManager->addTip(new HealthTip("Stay Socially Connected", "Maintain strong social connections to support your mental health."));
    $healthTipManager->addTip(new HealthTip("Drink Herbal Teas", "Enjoy caffeine-free herbal teas for relaxation and hydration."));
    $healthTipManager->addTip(new HealthTip("Practice Mindfulness", "Engage in mindfulness practices to improve mental clarity and emotional well-being."));
    $healthTipManager->addTip(new HealthTip("Strengthen Your Core", "Incorporate core exercises into your routine for better posture and balance."));
    $healthTipManager->addTip(new HealthTip("Eat Small, Frequent Meals", "Eating smaller, more frequent meals can improve metabolism and energy levels."));
    $healthTipManager->addTip(new HealthTip("Avoid Late-Night Snacking", "Try not to eat late at night to avoid digestive discomfort and weight gain."));
    $healthTipManager->addTip(new HealthTip("Wash Your Face Twice a Day", "Cleanse your face to remove dirt, oil, and makeup to prevent skin problems."));
    $healthTipManager->addTip(new HealthTip("Exercise Your Brain", "Challenge your mind with puzzles, reading, or learning something new."));
    $healthTipManager->addTip(new HealthTip("Get Fresh Air Daily", "Spend time outdoors to boost your mood and vitamin D levels."));
    $healthTipManager->addTip(new HealthTip("Stay Hydrated with Healthy Drinks", "Choose water, herbal teas, or infused water to stay hydrated instead of sugary drinks."));
    $healthTipManager->addTip(new HealthTip("Take Regular Breaks", "Stand up, stretch, and take breaks regularly to reduce strain from sitting."));
    $healthTipManager->addTip(new HealthTip("Chew Food Slowly", "Take time to chew food thoroughly to aid digestion and prevent overeating."));
    $healthTipManager->addTip(new HealthTip("Practice Good Posture", "Ensure proper posture to prevent back and neck pain."));
    $healthTipManager->addTip(new HealthTip("Drink Green Tea", "Green tea is rich in antioxidants and may support overall health."));
    $healthTipManager->addTip(new HealthTip("Take Vitamin Supplements", "Consider vitamin supplements if your diet lacks specific nutrients."));
    $healthTipManager->addTip(new HealthTip("Avoid Overworking", "Take regular breaks during work to avoid burnout and maintain productivity."));
    $healthTipManager->addTip(new HealthTip("Spend Time with Pets", "Interacting with pets can reduce stress and improve mental well-being."));
    $healthTipManager->addTip(new HealthTip("Limit Screen Time", "Reduce the amount of time spent in front of screens to improve sleep and reduce eye strain."));
    $healthTipManager->addTip(new HealthTip("Eat Seasonal Foods", "Consume seasonal fruits and vegetables for optimal nutrition."));
    $healthTipManager->addTip(new HealthTip("Use Essential Oils", "Incorporate essential oils like lavender or peppermint for relaxation and focus."));
    $healthTipManager->addTip(new HealthTip("Stay Positive", "Focus on the positive aspects of life to improve mental health and well-being."));
    
    
    // Display all health tips
    $healthTipManager->displayTips();
    ?>
</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | Health Tips System | <a href="../Patient/patientPortal.php">Patient Portal</a> | All rights reserved.</p>
</footer>

</body>
</html>
