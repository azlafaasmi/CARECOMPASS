<?php
// healthArticles.php

class HealthArticle {
    private $title;
    private $author;
    private $date;
    private $content;

    public function __construct($title, $author, $date, $content) {
        $this->title = $title;
        $this->author = $author;
        $this->date = $date;
        $this->content = $content;
    }

    public function toArray() {
        return [
            'title' => $this->title,
            'author' => $this->author,
            'date' => $this->date,
            'content' => $this->content
        ];
    }
}

class HealthArticleManager {
    private $articles = [];

    public function addArticle(HealthArticle $article) {
        $this->articles[] = $article;
    }

    public function displayArticles() {
        echo "<table border='1'><tr><th>Title</th><th>Author</th><th>Date</th><th>Content</th></tr>";
        foreach ($this->articles as $article) {
            $articleDetails = $article->toArray();
            echo "<tr><td>{$articleDetails['title']}</td><td>{$articleDetails['author']}</td><td>{$articleDetails['date']}</td><td>{$articleDetails['content']}</td></tr>";
        }
        echo "</table>";
    }
}

$articleManager = new HealthArticleManager();

$articles = [
    ["Understanding Hypertension", "Dr. Emily Carter", "2002-05-15", "Hypertension, or high blood pressure, increases the risk of heart disease and stroke. Regular monitoring and a healthy lifestyle can help manage it."],
    ["The Role of Vaccines in Public Health", "Dr. John Smith", "2005-07-21", "Vaccines prevent serious diseases like measles, polio, and COVID-19, saving millions of lives worldwide every year."],
    ["Diabetes Management and Prevention", "Dr. Lisa Green", "2010-03-11", "Managing diabetes involves a healthy diet, regular exercise, and monitoring blood sugar levels to prevent complications."],
    ["Heart Disease: Prevention and Treatment", "Dr. Michael Brown", "2012-09-14", "Heart disease is the leading cause of death globally. Lifestyle changes and medical treatments can reduce the risk."],
    ["The Importance of Mental Health Awareness", "Dr. Sarah White", "2015-04-23", "Mental health is as crucial as physical health. Seeking therapy and practicing self-care can improve well-being."],
    ["Common Respiratory Diseases", "Dr. Alan Grey", "2017-08-30", "Conditions like asthma and COPD require early diagnosis and proper management to improve quality of life."],
    ["The Impact of Obesity on Health", "Dr. Olivia Adams", "2018-06-12", "Obesity increases the risk of diabetes, heart disease, and other conditions. A balanced diet and physical activity help in maintaining a healthy weight."],
    ["Advancements in Cancer Treatment", "Dr. Robert Wilson", "2019-01-25", "New therapies, including immunotherapy and targeted treatments, have improved cancer survival rates."],
    ["The Link Between Diet and Chronic Diseases", "Dr. Sophie Johnson", "2020-11-10", "A poor diet contributes to chronic illnesses like diabetes, heart disease, and obesity. A balanced diet is key to prevention."],
    ["Understanding Stroke and Recovery", "Dr. David Lee", "2021-07-18", "Stroke can be life-threatening but early intervention and rehabilitation improve recovery outcomes."],
    ["How to Strengthen Your Immune System", "Dr. Emily Carter", "2022-05-20", "A strong immune system reduces the risk of infections. Proper nutrition, sleep, and hygiene play a vital role."],
    ["The Role of Sleep in Health", "Dr. John Smith", "2016-03-28", "Sleep affects memory, mood, and immune function. Poor sleep can increase the risk of chronic diseases."],
    ["Managing Allergies Effectively", "Dr. Lisa Green", "2014-09-05", "Allergies affect millions worldwide. Identifying triggers and using medication can help manage symptoms."],
    ["Kidney Health and Prevention of Disease", "Dr. Michael Brown", "2008-12-11", "Healthy kidneys filter waste and excess fluid. A healthy diet and hydration are crucial for kidney function."],
    ["The Science of Pain Management", "Dr. Sarah White", "2013-06-22", "Chronic pain affects daily life. Medication, physical therapy, and alternative treatments help manage it."],
    ["Liver Disease and How to Prevent It", "Dr. Alan Grey", "2007-10-30", "Liver diseases like hepatitis and fatty liver disease can be prevented with a healthy diet and avoiding alcohol abuse."],
    ["The Importance of Medical Screenings", "Dr. Olivia Adams", "2003-04-07", "Regular medical check-ups help in early disease detection and improve treatment outcomes."],
    ["The Future of Telemedicine", "Dr. Robert Wilson", "2009-08-19", "Telemedicine has revolutionized healthcare by making medical consultations more accessible."],
    ["Understanding Autoimmune Diseases", "Dr. Sophie Johnson", "2011-11-03", "Autoimmune diseases occur when the immune system attacks the body. Early diagnosis and treatment can help manage symptoms."],
    ["How to Maintain Healthy Vision", "Dr. David Lee", "2006-02-14", "Regular eye exams, proper nutrition, and protecting eyes from strain help maintain vision health."],
];

foreach ($articles as $data) {
    $article = new HealthArticle($data[0], $data[1], $data[2], $data[3]);
    $articleManager->addArticle($article);
}
?>
<style>
    body {
    font-family: Arial, sans-serif;
    background: url('../src/background.avif') no-repeat center center fixed;
    background-size: cover;
    color: rgb(124, 127, 130);
    margin: 0;
    padding: 0;
}

header {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 15px 20px;
    background-color: rgba(128, 132, 135, 0.8);
    color: black;
    text-align: center;
}

footer {
    text-align: center;
    padding: 15px 20px;
    background-color: rgba(79, 83, 86, 0.8);
    color: black;
    bottom: 0;
    width: 100%;
}

.container {
    width: 80%;
    margin: 50px auto;
    background-color: rbg(255, 255, 255, 0.9);
    padding: 20px;
    color:black;
    border: 3px solid black;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    color:black;

}

table, th, td {
    border: 2px solid black;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #ccc;
}

</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Articles</title>
</head>
<body>
    <header>
        <h1>Health Articles</h1>
    </header>
    <div class="container">
        <?php $articleManager->displayArticles(); ?>
    </div>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>
