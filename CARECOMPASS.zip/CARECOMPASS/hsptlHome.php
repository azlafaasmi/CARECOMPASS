<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: url('./src/background.avif') no-repeat center center fixed;
      background-size: cover;
      color: rgb(104, 104, 111);
      margin: 0;
    }

    header {
      background: rgb(124, 132, 132);
      color: black;
      padding: 15px;
      top: 0;
      z-index: 1000;
      text-align: center;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .hero {
      height: 25vh;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: black;
      background: rbg(255, 255, 255, 0.8);
      margin: 20px auto;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .hero h2 {
      font-size: 36px;
      margin: 0;
    }

    .img img {
      max-width: 80%;
      height: auto;
      display: block;
      margin: 20px auto;
      border: 3px solid black;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .section {
      padding: 40px 20px;
      margin: 20px auto;
      max-width: 900px;
      background: rbg(255, 255, 255, 0.9);
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      border:3px solid black;
    }

    .section h2 {
      font-size: 28px;
      margin-bottom: 20px;
      color: rgb(15, 15, 16);
      border-bottom: 3px solid rgb(112, 117, 117);
      display: inline-block;
      padding-bottom: 5px;
    }

    .section p {
      max-width: 800px;
      margin: 0 auto;
      font-size: 18px;
      color: #555;
      line-height: 1.8;
    }

    footer {
      background: rgb(112, 117, 117);
      color: #fff;
      text-align: center;
      padding: 15px;
      margin-top: 20px;
      font-size: 16px;
    }

    footer a {
      color: rgb(11, 21, 161);
      text-decoration: none;
    }

    footer a:hover {
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .hero h2 {
        font-size: 24px;
      }

      .section h2 {
        font-size: 24px;
      }

      .section p {
        font-size: 16px;
      }

      .img img {
        max-width: 90%;
      }
    }
  </style>
</head>
<body>
<header>
  <h1>Welcome to CARECOMPASS HOSPITAL</h1>
</header>

<section class="hero">
  <div>
    <h2>Your Health, Our Priority</h2>
  </div>
</section>

<section class="img">
  <img src="./src/hospital.jpg" alt="Hospital Photo">
</section>

<section class="section about">
  <h2>About Us</h2>
  <p>
    At CARECOMPASS HOSPITAL, we are dedicated to providing exceptional healthcare services to our community. Our mission is to offer compassionate care and the latest in medical technology to ensure the best outcomes for our patients.
  </p>
</section>

<section class="section mission">
  <h2>Our Mission</h2>
  <p>
    To deliver world-class healthcare services that meet the needs of our diverse community, with a focus on patient-centered care, innovation, and excellence.
  </p>
</section>

<section class="section vision">
  <h2>Our Vision</h2>
  <p>
    To be recognized as a leader in healthcare, inspiring trust and confidence through compassionate care, cutting-edge technology, and a commitment to improving lives.
  </p>
</section>

<footer>
  <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | <a href="ContactUs.php">Contact Us</a> | All rights reserved.</p>
</footer>

</body>
</html>
