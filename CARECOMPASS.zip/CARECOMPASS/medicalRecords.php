<?php
require_once('./Connection.php'); // Ensure this file correctly connects to your database

// Ensure the database connection is successful
if ($conp->connect_error) {
    die("Connection failed: " . $conp->connect_error);
}

// Handle update request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $record_id = $_POST['record_id'];
    $diagnosis = $_POST['diagnosis'];
    $prescription = $_POST['prescription'];
    $test_results = $_POST['test_results'];

    // Update query
    $updateQuery = "UPDATE medical_records SET diagnosis=?, prescription=?, test_results=? WHERE record_id=?";
    $stmt = $conp->prepare($updateQuery);
    $stmt->bind_param("sssi", $diagnosis, $prescription, $test_results, $record_id);

    if ($stmt->execute()) {
        echo "<script>alert('Medical record updated successfully!'); window.location.href='';</script>";
    } else {
        echo "<script>alert('Error updating medical record!');</script>";
    }
}

// Query to fetch all medical record details
$query = "SELECT record_id, staff_id, patient_name, diagnosis, prescription, test_results, record_date FROM medical_records";
$result = $conp->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('./src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            font-weight: bold;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            font-weight: bold;
            width: 100%;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: rbg(255, 255, 255, 0.8);
        }

        table, th, td {
            border: 1px solid black;
            color: black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: rgba(128, 132, 135, 0.8);
        }

        tr:nth-child(even) {
            background-color: rgba(240, 240, 240, 0.7);
        }

        .update-form {
            display: flex;
            gap: 5px;
        }

        input[type="text"], textarea {
            width: 100%;
            padding: 5px;
        }

        button {
            padding: 8px 12px;
            background-color:rgb(108, 109, 108);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background-color:rgb(9, 9, 9);
            transform: scale(1.05);
        }

        button:active {
            background-color:rgb(223, 225, 223);
            transform: scale(0.98);
        }

    </style>
</head>
<body>

<header>
    <h1>Medical Records</h1>
</header>

<main>
    <?php
    // Check if the result contains rows
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<thead><tr>
                <th>Record ID</th>
                <th>Staff ID</th>
                <th>Patient Name</th>
                <th>Diagnosis</th>
                <th>Prescription</th>
                <th>Test Results</th>
                <th>Record Date</th>
                <th>Action</th>
              </tr></thead>";
        echo "<tbody>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['record_id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['staff_id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['patient_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['diagnosis']) . "</td>";
            echo "<td>" . htmlspecialchars($row['prescription']) . "</td>";
            echo "<td>" . htmlspecialchars($row['test_results']) . "</td>";
            echo "<td>" . htmlspecialchars($row['record_date']) . "</td>";
            echo "<td>
                    <form class='update-form' method='POST'>
                        <input type='hidden' name='record_id' value='" . htmlspecialchars($row['record_id']) . "'>
                        <input type='text' name='diagnosis' value='" . htmlspecialchars($row['diagnosis']) . "' required>
                        <textarea name='prescription' required>" . htmlspecialchars($row['prescription']) . "</textarea>
                        <textarea name='test_results' required>" . htmlspecialchars($row['test_results']) . "</textarea>
                        <button type='submit' name='update'>Update</button>
                    </form>
                  </td>";
            echo "</tr>";
        }
        
        echo "</tbody></table>";
    } else {
        echo "<p>No medical records found.</p>";
    }
    ?>
</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
</footer>

</body>
</html>

<?php
$conp->close();
?>
