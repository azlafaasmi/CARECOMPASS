<?php
require_once('./Connection.php');
session_start();

// Function to sanitize input
function sanitizeInput($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Load the doctor.json file
$doctorFile = './Staff/doctor.json';
$doctorList = [];

if (file_exists($doctorFile)) {
    $jsonData = file_get_contents($doctorFile);
    $doctorData = json_decode($jsonData, true);
    if (isset($doctorData['doctor_names'][0]) && is_array($doctorData['doctor_names'][0])) {
        $doctorList = $doctorData['doctor_names'][0]; // Extracting doctor names
    } else {
        $_SESSION['error'] = "Error: doctor.json file structure is incorrect!";
    }
} else {
    $_SESSION['error'] = "Error: doctor.json file not found!";
}

// Define available time slots (7 slots per hour, 10-minute intervals, including the new one)
$timeSlots = [
    "09:00 - 09:10", "09:10 - 09:20", "09:20 - 09:30", "09:30 - 09:40", "09:40 - 09:50", "09:50 - 10:00",
    "10:00 - 10:10", "10:10 - 10:20", "10:20 - 10:30", "10:30 - 10:40", "10:40 - 10:50", "10:50 - 11:00",
    "11:00 - 11:10", "11:10 - 11:20", "11:20 - 11:30", "11:30 - 11:40", "11:40 - 11:50", "11:50 - 12:00",
    "12:00 - 12:10" // New time slot added
];

// Available statuses
$statuses = ["Scheduled", "Completed", "Cancelled", "Rescheduled"];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['bookAppointment'])) {
    $patient_id = isset($_POST['patient_id']) ? intval($_POST['patient_id']) : 0;
    $doctor_name = isset($_POST['doctor_name']) ? sanitizeInput($_POST['doctor_name']) : '';
    $appointment_date = isset($_POST['appointment_date']) ? sanitizeInput($_POST['appointment_date']) : '';
    $appointment_time = isset($_POST['appointment_time']) ? sanitizeInput($_POST['appointment_time']) : '';
    $slot = isset($_POST['slot']) ? sanitizeInput($_POST['slot']) : ''; // slot field
    $status = isset($_POST['status']) ? sanitizeInput($_POST['status']) : '';


        // Prepare the SQL statement
        $sql = "INSERT INTO appointments (patient_id, doctor_name, appointment_date, appointment_time, slot, status) 
                VALUES (?, ?, ?, ?, ?, ?)";

        // Prepare statement
        if ($stmt = $conp->prepare($sql)) {
            // Bind parameters
            $stmt->bind_param("isssss", $patient_id, $doctor_name, $appointment_date, $appointment_time, $slot, $status);

            // Execute the statement
            if ($stmt->execute()) {
                $_SESSION['success'] = "Appointment booked successfully!";
            } else {
                $_SESSION['error'] = "Error saving appointment: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        } else {
            $_SESSION['error'] = "Error preparing the SQL statement: " . $conp->error;
        }

        // Redirect to the same page
        header("Location: {$_SERVER['PHP_SELF']}");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('./src/background.avif') ;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 60%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border: 2px solid black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            font-weight: bold;
        }
        input, select {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid black;
            border-radius: 5px;
        }
        button {
            background-color: rgb(126, 126, 126);
            color: white;
            padding: 12px 20px;
            border: 1px solid black;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: rgb(7, 7, 7);
        }
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .header, .footer {
            text-align: center;
            padding: 15px;
            background-color: rgb(126, 126, 126);
            color: black;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Hospital Appointment Booking</h1>
    </div>
    <div class="container">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        <h2>Book an Appointment</h2>
        <form action="" method="POST">
            <label for="patient_id">Patient ID</label>
            <input type="number" id="patient_id" name="patient_id" required>
            <label for="doctor_name">Select Doctor</label>
            <select id="doctor_name" name="doctor_name" required>
                <option value="">Select Doctor</option>
                <?php foreach ($doctorList as $doctor): ?>
                    <option value="<?= sanitizeInput($doctor) ?>"><?= sanitizeInput($doctor) ?></option>
                <?php endforeach; ?>
            </select>
            <label for="appointment_date">Appointment Date</label>
            <input type="date" id="appointment_date" name="appointment_date" required>
            <label for="appointment_time">Appointment Time</label>
            <input type="time" id="appointment_time" name="appointment_time" required>
            <label for="slot">Slot</label>
            <select id="slot" name="slot" required>
                <option value="">Select Slot</option>
                <?php foreach ($timeSlots as $slot): ?>
                    <option value="<?= $slot ?>"><?= $slot ?></option>
                <?php endforeach; ?>
            </select>
            <label for="status">Status</label>
            <select id="status" name="status" required>
                <?php foreach ($statuses as $status): ?>
                    <option value="<?= $status ?>"><?= $status ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" name="bookAppointment">Book Appointment</button>
        </form>
    </div>
    <div class="footer">
        <h4>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</h4>
    </div>
</body>
</html>
