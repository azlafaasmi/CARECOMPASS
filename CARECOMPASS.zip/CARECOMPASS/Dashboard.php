<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CARECOMPASS HOSPITAL</title>

  <style>
    body {
      font-family: Arial, sans-serif;
      background: url('./src/background.avif') ;
      background-size: cover;
      color: rgb(124, 127, 130);
      position: relative;
    }

    .full-body-image {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      opacity: 0.2;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 20px;
      background-color: rgba(128, 132, 135, 0.8);
      color: #fff;
    }

    .name {
      font-family: sans-serif;
      font-size: 23px;
      color: white;
      font-weight: bold;
    }

    .nav-menu {
      display: flex;
      gap: 15px;
    }

    .nav-menu a {
  color: #fff;
  text-decoration: none;
  font-weight: bold;
  padding: 10px 15px;
  border-radius: 5px;
  transition: background-color 0.3s, transform 0.3s;
}

.nav-menu a:hover {
  background-color:rgb(7, 7, 7); 
  transform: scale(1.05);
}


    .cta-buttons {
      display: flex;
      gap: 15px;
    }

    .cta-buttons a {
      padding: 12px 20px;
      color: #fff;
      background-color:rgb(175, 173, 173);
      border-radius: 5px;
      text-decoration: none;
      font-weight: bold;
      font-size: 16px;
      transition: background-color 0.3s, transform 0.3s;
    }

    .cta-buttons a:hover {
      background-color:rgb(13, 13, 13);
      transform: scale(1.05);
    }

    .contact-info {
      display: flex;
      gap: 15px;
      align-items: center;
      font-size: 14px;
    }

    .contact-info span {
      font-weight: bold;
    }

    .search-bar {
      margin: 20px 0;
      text-align: center;
    }

    .search-bar input {
      width: 300px;
      padding: 10px;
      border: 2px solid rgb(78, 87, 94);
      border-radius: 5px;
    }

    main {
      text-align: center;
      padding: 50px 20px;
      color: #fff;
      background: rgba(0, 0, 0, 0.5);
      margin: 20px auto;
      width: 80%;
      border-radius: 10px;
    }

    .main-content {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      margin-top: 30px;
    }

    .logo {
      width: 100px;
      height: 100px;
    }

    .service-card {
      width: 45%;
      background-color: rgba(198, 193, 193, 0.42);
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 10px;
      text-align: center;
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .service-card:hover {
      transform: scale(1.05);
      box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
    }

    .service-card img {
      width: 100%;
      height: auto;
      border-radius: 10px;
      transition: transform 0.3s;
    }

    .service-card:hover img {
      transform: scale(1.1);
    }

    footer {
      text-align: center;
      padding: 15px;
      background-color: rgba(79, 83, 86, 0.8);
      color: #fff;
      margin-top: 20px;
    }
  </style>
</head>

<body>

  <header>
    <div class="name">
      <span>CARECOMPASS HOSPITAL</span>
    </div>

    <nav class="nav-menu">
      <a href="./hsptlHome.php">Home</a>
      <a href="AboutUs.php">About Us</a>
      <a href="./Services.php">Services</a>
      <a href="./Users/userDashboard.php">Users</a>
      <a href="ContactUs.php">Contact Us</a>
    </nav>

    <div class="cta-section">
      <div class="contact-info">
        <span>Emergency: +123-456-7890</span>
        <span>Main: +987-654-3210</span>
      </div><br>
      <div class="cta-buttons">
        <a href="./Appointment.php">Book Appointment</a>
        <a href="./Patient/patientRegistration.php">Patient Portal</a>
      </div>
    </div>
  </header>

  <div class="logo">
    <img src="./src/re.png" alt="Hospital Logo">
  </div><br><br><br><br><br>

  <main>
    <h1>Welcome to CARECOMPASS HOSPITAL</h1>
    <p>Your health is our priority. Explore our services, meet our expert doctors, and book an appointment today.</p>

    <div class="main-content">
      <div class="service-card">
        <img src="./src/emerg.jpg" alt="Emergency Care">
        <h3>Emergency Care</h3>
        <p>We provide fast and reliable emergency care for critical situations.</p>
      </div>
      <div class="service-card">
        <img src="src/img.jpg" alt="General Consultations">
        <h3>General Consultations</h3>
        <p>Consult our experienced doctors for general health concerns and wellness checks.</p>
      </div>
    </div>
  </main>

  <footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
  </footer>

</body>

</html>
