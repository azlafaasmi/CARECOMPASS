<?php
require_once('./Connection.php'); // Include your DB connection file

// Check if the bill_id is passed in the URL
if (isset($_GET['bill_id'])) {
    $billId = mysqli_real_escape_string($conp, $_GET['bill_id']); // Sanitize input

    // Query to fetch bill details based on the bill_id
    $query = "SELECT * FROM billing WHERE bill_id = '$billId'";
    $result = mysqli_query($conp, $query);

    // Fetch the bill data if found
    if ($result && mysqli_num_rows($result) > 0) {
        $billData = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Bill not found.'); window.location.href='Billing.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('Invalid request.'); window.location.href='Billing.php';</script>";
    exit;
}

// Handle form submission to update bill details
if (isset($_POST['update'])) {
    $billId = mysqli_real_escape_string($conp, $_POST['bill_id']);
    $patient_id = mysqli_real_escape_string($conp, $_POST['patient_id']);
    $appointment_id = mysqli_real_escape_string($conp, $_POST['appointment_id']);
    $payment_method = mysqli_real_escape_string($conp, $_POST['payment_method']);
    $amount = mysqli_real_escape_string($conp, $_POST['amount']);
    $billing_date = mysqli_real_escape_string($conp, $_POST['billing_date']);
    $status = mysqli_real_escape_string($conp, $_POST['status']);
    
    // Update query to modify bill details
    $updateQuery = "UPDATE billing SET 
        patient_id = '$patient_id', 
        appointment_id = '$appointment_id', 
        payment_method = '$payment_method', 
        total_amount = '$amount', 
        payment_date = '$billing_date', 
        payment_status = '$status' 
        WHERE bill_id = '$billId'";

    if (mysqli_query($conp, $updateQuery)) {
        echo "<script>alert('Bill updated successfully.'); window.location.href='Billing.php';</script>";
    } else {
        echo "<script>alert('Error updating bill details.');</script>";
    }
}

// Fetch patient details
$patientQuery = "SELECT patient_name FROM patients WHERE patient_id = '{$billData['patient_id']}'";
$patientResult = mysqli_query($conp, $patientQuery);
$patient = mysqli_fetch_assoc($patientResult);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Billing</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background: url('./src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            width: 100%;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            width: 100%;
            bottom: 0;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            color: black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 2px solid black;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid gray;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: rgb(129, 129, 129);
            color: white;
            border: 1px solid black;
            cursor: pointer;
        }

        button:hover {
            background-color: rgb(5, 6, 5);
        }    
    </style>
</head>
<body>

    <header>
        <h1>Update Billing Information</h1>
    </header>

    <div class="container">
    <h2>Edit Billing:<?php echo htmlspecialchars($patient['patient_name']); ?></h2>

        <form method="POST">
            <input type="hidden" name="bill_id" value="<?php echo htmlspecialchars($billData['bill_id']); ?>">

            <label for="patient_id">Patient ID</label>
            <input type="text" id="patient_id" name="patient_id" value="<?php echo htmlspecialchars($billData['patient_id']); ?>" required>

            <label for="appointment_id">Appointment ID</label>
            <input type="text" id="appointment_id" name="appointment_id" value="<?php echo htmlspecialchars($billData['appointment_id']); ?>" required>



            <label for="amount">Amount</label>
            <input type="text" id="amount" name="amount" value="<?php echo htmlspecialchars($billData['total_amount']); ?>" required>

            <label for="billing_date">Billing Date</label>
            <input type="date" id="billing_date" name="billing_date" value="<?php echo htmlspecialchars($billData['payment_date']); ?>" required>
            <label for="payment_method">Payment Method</label>
            <select id="payment_method" name="payment_method" required>
                <option value="Cash" <?php echo $billData['payment_method'] == 'Cash' ? 'selected' : ''; ?>>Cash</option>
                <option value="Credit Card" <?php echo $billData['payment_method'] == 'Credit Card' ? 'selected' : ''; ?>>Credit Card</option>
                <option value="Debit Card" <?php echo $billData['payment_method'] == 'Debit Card' ? 'selected' : ''; ?>>Debit Card</option>
                <option value="Insurance" <?php echo $billData['payment_method'] == 'Insurance' ? 'selected' : ''; ?>>Insurance</option>
                <option value="Online Transfer" <?php echo $billData['payment_method'] == 'Online Transfer' ? 'selected' : ''; ?>>Online Transfer</option>
            </select>
            <label for="status">Status</label>
            <select id="status" name="status" required>
                <option value="Paid" <?php echo $billData['payment_status'] == 'Paid' ? 'selected' : ''; ?>>Paid</option>
                <option value="Unpaid" <?php echo $billData['payment_status'] == 'Failed' ? 'selected' : ''; ?>>Failed</option>
                <option value="Pending" <?php echo $billData['payment_status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
            </select>

            <button type="submit" name="update">Update Bill</button>
        </form>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>

</body>
</html>
