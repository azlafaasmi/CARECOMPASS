<?php
require_once('../Connection.php'); 

if (isset($_POST['submit'])) {
    // Capture and sanitize input
    $patient_id = mysqli_real_escape_string($conp, $_POST['patient_id']);
    $nic = mysqli_real_escape_string($conp, $_POST['nic']);
    $name = mysqli_real_escape_string($conp, $_POST['name']);
    $gender = mysqli_real_escape_string($conp, $_POST['gender']);
    $dob = mysqli_real_escape_string($conp, $_POST['dob']);
    $contact_number = mysqli_real_escape_string($conp, $_POST['contact_number']);
    $email = mysqli_real_escape_string($conp, $_POST['email']);
    $password = mysqli_real_escape_string($conp, $_POST['password']);
    $age = mysqli_real_escape_string($conp, $_POST['age']);
    $address = mysqli_real_escape_string($conp, $_POST['address']);
    $blood_group = mysqli_real_escape_string($conp, $_POST['blood_group']);

    // Insert into patients table
    $patient_query = "INSERT INTO patients (patient_id, NIC, patient_name, patient_gender, dob, Password, patient_age, cont_no, email, address, blood_group) 
                      VALUES ('{$patient_id}', '{$nic}', '{$name}', '{$gender}', '{$dob}', '{$password}', '{$age}', '{$contact_number}', '{$email}', '{$address}', '{$blood_group}')";

    if (mysqli_query($conp, $patient_query)) {
        // Insert login credentials into users table
        $user_query = "INSERT INTO users (user_name, user_password, role) 
                       VALUES ('{$name}', '{$password}', 'Patient')"; // Store plain password here

        if (mysqli_query($conp, $user_query)) {
            echo "<script>alert('Patient added successfully! Login credentials created.');</script>";
        } else {
            echo "<script>alert('Patient added, but there was an error creating login credentials.');</script>";
        }
    } else {
        echo "<script>alert('Error adding patient. Please try again.');</script>";
        echo "<script>window.location.href='patientRegistration.php';</script>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    // Handle login
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conp->prepare("SELECT user_name, user_password FROM users WHERE user_name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_name, $stored_password);
        $stmt->fetch();

        if ($password == $stored_password) { // Check the plain password
            session_start();
            $_SESSION['user_name'] = $user_name;
            echo "Login successful! Redirecting...";
            header("Location: patientPortal.php");
            exit;
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "No user found with the given username!";
    }
}
?>

  <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }
        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }
        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border: 1px solid black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            color: black;

        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="date"],
        input[type="tel"],
        select,
        input[type="password"],
        input[type="number"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid gray;
            border-radius: 5px;
        }
        button {
            background-color: rgb(126, 126, 126);
            color: white;
            padding: 12px 20px;
            border: 1px solid black;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: rgb(7, 7, 7);
        }
        .form-footer {
            text-align: center;
            color: black;
            margin-top: 20px;
        }
    </style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration & Login</title>

</head>
<body>
    <header>
        <h1>Patient Registration & Login</h1>
    </header>

    <div class="container">
        <!-- Registration Form -->
        <form action="patientRegistration.php" method="POST">
            <h2>Register as Patient</h2>
            <label for="patient_id">Patient ID</label>
            <input type="text" id="patient_id" name="patient_id" required>

            <label for="nic">NIC</label>
            <input type="text" id="nic" name="nic" required>

            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>

            <label for="gender">Gender</label>
            <select id="gender" name="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label for="dob">Date of Birth</label>
            <input type="date" id="dob" name="dob" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <label for="age">Age</label>
            <input type="number" id="age" name="age" required>

            <label for="contact_number">Contact Number</label>
            <input type="tel" id="contact_number" name="contact_number" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="address">Address</label>
            <input type="text" id="address" name="address">

            <label for="blood_group">Blood Group</label>
            <select id="blood_group" name="blood_group" required>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
            </select>

            <button type="submit" name="submit">Register</button>
        </form>

        <!-- Login Form -->
        <form action="patientRegistration.php" method="POST">
            <h2>Login</h2>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" name="login">Login</button>
        </form>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>
