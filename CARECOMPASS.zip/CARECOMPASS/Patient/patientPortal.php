<?php
session_start();
require_once('../Connection.php'); // Ensure the database connection is included

// Check if user is logged in and is a Patient
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'Patient') {
    echo "<script>alert('Access denied! Please login as a Patient.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}

// Get the logged-in patient's name
$patient_name = $_SESSION['username'] ?? null;

if ($patient_name) {
    // Fetch patient data based on the patient name
    $query = "SELECT * FROM patients WHERE patient_name = '$patient_name'";
    $result = mysqli_query($conp, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $patient = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Error fetching patient details or no records found.');</script>";
        exit();
    }
} else {
    echo "<script>alert('No patient session found. Please log in again.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') ;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5em;
        }

        header p {
            font-size: 1.2em;
            margin-top: 10px;
        }
        header a {
            text-decoration: underline;
            color:black;
        }

        main {
            max-width: 700px;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(3, 3, 3, 0.1);
            border: 1px solid black;
        }

        .section {
            border-radius: 10px;
            margin-bottom: 30px;
            border:1px solid black;
        }

        .section h2 {
            color: black;
            text-align: center;
            margin-bottom: 20px;
        }

        .section ul {
            list-style: none;
            text-align: center;
            padding: 0;
        }

        .section ul li {
            margin: 10px 0;
        }

        .section ul li a {
            text-decoration: none;
            color: black;
            font-size: 1.0em;
            display: block;
            padding: 10px;
            background: rgba(128, 132, 135, 0.1);
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        .section ul li a:hover {
            background: rgba(128, 132, 135, 0.2);
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }

        .cta {
            text-align: center;
            margin-top: 20px;
        }

        .cta a {
            display: inline-block;
            text-decoration: none;
            background-color:rgb(116, 118, 120);
            color: white;
            padding: 10px 20px;
            font-size: 1.2em;
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        .cta a:hover {
            background-color:rgb(7, 7, 7);
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to the Patient Portal</h1>
        <p>Hello, <?php echo htmlspecialchars($patient['patient_name'] ?? 'Patient'); ?>!</p>
        <a href="../Users/Login.php">Logout</a>
    </header>

    <main>
        <section class="section">
            <h2>Quick Links</h2>
            <ul>
                <li><a href="../Appointment.php">Book An Appointment</a></li>
                <li><a href="../Patient/viewReports.php">View Lab Reports</a></li>
                <li><a href="../Patient/viewRecords.php">View Medical Records</a></li>
                <li><a href="../addingPayment.php">Pay Your Bills</a></li>
                <li><a href="../Staff/doctorList.php">Search Doctor</a></li>

            </ul>
        </section>

        <section class="section">
            <h2>Health Resources</h2>
            <ul>
                <li><a href="../HealthResources/healthArticles.php">Read Health Articles</a></li>
                <li><a href="../HealthResources/healthTips.php">Explore Wellness Tips</a></li>
            </ul>
        </section>

        <div class="cta">
            <a href="../Dashboard.php">Back to Dashboard</a>
        </div>

    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html> 