<?php
session_start();
require_once('../Connection.php'); // Ensure the database connection is included

// Get the logged-in patient's username
$patient_name = $_SESSION['username'] ?? null;

if ($patient_name) {
    // Prepare and execute the query to fetch lab reports for the logged-in patient
    $stmt = $conp->prepare("SELECT report_id,staff_id, test_type, report_date, test_results, remarks FROM lab_reports WHERE patient_name = ?");
    if (!$stmt) {
        die("SQL error: " . htmlspecialchars($conp->error)); // Display any SQL errors
    }
    
    $stmt->bind_param("s", $patient_name);
    if (!$stmt->execute()) {
        die("Execution error: " . htmlspecialchars($stmt->error)); // Display execution errors
    }

    $result = $stmt->get_result();

    // Fetch lab reports and store in an array
    $reports = [];
    while ($row = $result->fetch_assoc()) {
        $reports[] = $row;
    }
} else {
    echo "<script>alert('No patient session found. Please log in again.');</script>";
    header("Location: ../Users/Login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(83, 82, 82);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background-color: rgba(92, 92, 93, 0.9);
            color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2rem;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.95);
            padding: 50px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            border: 5px solid gray;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid gray;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: rgba(92, 92, 93, 0.8);
            color: white;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(89, 90, 91, 0.9);
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.2);
        }

        footer h3 {
            margin: 0;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <header>
        <h1>Your Lab Reports</h1>
    </header>

    <div class="container">
        <?php if (!empty($reports)): ?>
            <table>
                <tr>
                    <th>Report ID</th>
                    <th>Staff ID</th>
                    <th>Test Type</th>
                    <th>Test Results</th>
                    <th>Remarks</th>
                    <th>Report Date</th>
                </tr>
                <?php foreach ($reports as $report): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($report['report_id']); ?></td>
                        <td><?php echo htmlspecialchars($report['staff_id']); ?></td>
                        <td><?php echo htmlspecialchars($report['test_type']); ?></td>
                        <td><?php echo htmlspecialchars($report['test_results']); ?></td>
                        <td><?php echo htmlspecialchars($report['remarks']); ?></td>
                        <td><?php echo htmlspecialchars($report['report_date']); ?></td>

                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>No lab reports found for you.</p>
        <?php endif; ?>
    </div>

    <footer>
        <h3>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</h3>
    </footer>
</body>
</html>
