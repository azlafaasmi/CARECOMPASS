<?php
require_once('./Connection.php'); // Ensure this file correctly connects to your database

// Ensure the database connection is successful
if ($conp->connect_error) {
    die("Connection failed: " . $conp->connect_error);
}

// Handle update request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $report_id = $_POST['report_id'];
    $test_results = $_POST['test_results'];
    $remarks = $_POST['remarks'];

    // Update query
    $updateQuery = "UPDATE lab_reports SET test_results=?, remarks=? WHERE report_id=?";
    $stmt = $conp->prepare($updateQuery);
    $stmt->bind_param("ssi", $test_results, $remarks, $report_id);

    if ($stmt->execute()) {
        echo "<script>alert('Lab report updated successfully!'); window.location.href='';</script>";
    } else {
        echo "<script>alert('Error updating lab report!');</script>";
    }
}

// Query to fetch all lab report details
$query = "SELECT report_id, patient_name, staff_id, test_type, test_results, report_date, remarks FROM lab_reports";
$result = $conp->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('./src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            font-weight: bold;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            font-weight: bold;
            width: 100%;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: rbg(255, 255, 255, 0.8);
        }

        table, th, td {
            border: 1px solid black;
            color: black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: rgba(128, 132, 135, 0.8);
        }

        tr:nth-child(even) {
            background-color: rgba(240, 240, 240, 0.7);
        }

        .update-form {
            display: flex;
            gap: 5px;
        }

        input[type="text"], textarea {
            width: 100%;
            padding: 5px;
        }

        button {
            padding: 8px 12px;
            background-color:rgb(108, 109, 108);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background-color:rgb(9, 9, 9);
            transform: scale(1.05);
        }

        button:active {
            background-color:rgb(223, 225, 223);
            transform: scale(0.98);
        }
    </style>
</head>
<body>

<header>
    <h1>Lab Reports</h1>
</header>

<main>
    <?php
    // Check if the result contains rows
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<thead>
                <tr>
                    <th>Report ID</th>
                    <th>Patient Name</th>
                    <th>Staff ID</th>
                    <th>Test Type</th>
                    <th>Test Results</th>
                    <th>Report Date</th>
                    <th>Remarks</th>
                    <th>Action</th>
                </tr>
              </thead>";
        echo "<tbody>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['report_id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['patient_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['staff_id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['test_type']) . "</td>";
            echo "<td>" . htmlspecialchars($row['test_results']) . "</td>";
            echo "<td>" . htmlspecialchars($row['report_date']) . "</td>";
            echo "<td>" . htmlspecialchars($row['remarks']) . "</td>";
            echo "<td>
                    <form class='update-form' method='POST'>
                        <input type='hidden' name='report_id' value='" . htmlspecialchars($row['report_id']) . "'>
                        <input type='text' name='test_results' value='" . htmlspecialchars($row['test_results']) . "' required>
                        <textarea name='remarks' required>" . htmlspecialchars($row['remarks']) . "</textarea>
                        <button type='submit' name='update'>Update</button>
                    </form>
                  </td>";
            echo "</tr>";
        }
        
        echo "</tbody></table>";
    } else {
        echo "<p>No lab reports found.</p>";
    }
    ?>
</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
</footer>

</body>
</html>

<?php
$conp->close();
?>
