<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us</title>

  <style>
    body {
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      height: 100vh;
      font-family: Arial, sans-serif;
      background: url('./src/background.avif') no-repeat center center fixed;
      background-size: cover;
      color: rgb(124, 127, 130);
    }
    header {
      background:rgb(165, 166, 166);
      color: black;
      padding: 20px;
      text-align: center;
      font-size: 30px;
      font-weight: bold;
    }

    .about-section {
      
      padding: 40px 20px;
      text-align: center;
      
    }

    .about-section h2 {
      font-size: 36px;
      margin-bottom: 20px;
      color: #333;
    }

    .about-section p {
      max-width: 800px;
      margin: 0 auto;
      font-size: 18px;
      color: #555;
      font-family: Arial, sans-serif;
    }

    .team-section {
      padding: 1px 20px;
    }

    .team-section h2 {
      text-align: center;
      font-size: 36px;
      margin-bottom: 20px;
      color:black;
    }


    .team-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
    }

    .team-member {
      background:light gray;
      border: 2px solid gray;
      border-radius: 8px;
      padding: 20px;
      text-align: center;
      width: 250px;
      box-shadow: 0 4px 6px rgba(69, 3, 3, 0.1);
    }

    .team-member img {
      width: 250px;
      height: 200px;
      border-radius: 20%;
      margin-bottom: 15px;
      border: 2px solid gray;
    }

    .team-member h3 {
      font-size: 30px;
      margin-bottom: 5px;
      color: #333;
    }

    .team-member p {
      font-size: 19px;
      color: #555;
    }

    footer {
      text-align: center;
      padding: 20px;
      background:rgb(112, 114, 116);
      color:black;
      margin-top: 20px;
    }

    footer a {
      color:rgb(25, 25, 191);
      text-decoration: none;
    }

    footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <header>
  Who We Are
  </header>

  <section class="about-section">
    <p>
    At CARECOMPASS HOSPITAL, we are dedicated to providing exceptional healthcare services with a focus on 
    compassion and innovation. Our team of experts is committed to ensuring the best outcomes for our patients 
    while fostering a culture of care, excellence, and trust.
    </p>
  </section>

  <section class="team-section">
    <h2>Meet Our Team</h2>
    <div class="team-container">
      <div class="team-member">
        <img src="./src/Wilson.jpg" alt="Wilson">
        <h3>Dr. James Wilson</h3>
        <p>Chief Medical Officer</p>
      </div>
      <div class="team-member">
        <img src="./src/Evans.jpg" alt="Evans">
        <h3>Dr. Michael Evans</h3>
        <p>Director of Operations</p>
      </div>
      <div class="team-member">
        <img src="./src/Andrew.jpg" alt="Andrew">
        <h3>Dr. Andrew Hall</h3>
        <p>Head of Research</p>
      </div>
      <div class="team-member">
        <img src="./src/Clara.avif" alt="Clara">
        <h3>Dr.  Clara Lewis</h3>
        <p>Patient Care Manager</p>
      </div>
    </div>
  </section>

  <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital |<a href="ContactUs.php">Contact Us</a> | All rights reserved.</p>
    </footer>

</body>
</html>
