<?php
require_once('../Connection.php');
session_start();

// Fetch patient data
$query = "SELECT * FROM patients";
$result = mysqli_query($conp, $query);

if (!$result) {
    die("Database query failed: " . mysqli_error($conp));
}

// Handle deletion of a patient record
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Sanitize the ID to prevent SQL injection
    $deleteQuery = "DELETE FROM patients WHERE patient_id = $id";

    if (mysqli_query($conp, $deleteQuery)) {
        echo "<script>alert('Patient deleted successfully!'); window.location.href='patientProfile.php';</script>";
        exit; // Ensure no further code execution after redirect
    } else {
        echo "<script>alert('Error deleting patient: " . mysqli_error($conp) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Patients</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            width: 100%;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            width: 100%;
            bottom: 0;
        }

        /* Container and Table Styles */
        .container {
            width: 80%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 3px solid gray;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 2px solid gray;
        }

        th, td {
            padding: 12px;
            text-align: center;
            color: black;
        }

        /* Button Styles */
        button {
            background-color: rgb(129, 129, 129);
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: rgb(5, 6, 5);
        }
    </style>
</head>
<body>

    <header>
        <h2>Patient Records</h2>
    </header>

    <div class="container">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>NIC</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Date of Birth</th>
                        <th>Contact Number</th>
                        <th>Email</th>
                        <th>Blood Group</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['patient_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['NIC']); ?></td>
                            <td><?php echo htmlspecialchars($row['patient_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['patient_age']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($row['patient_gender'])); ?></td>
                            <td><?php echo htmlspecialchars($row['dob']); ?></td>
                            <td><?php echo htmlspecialchars($row['cont_no']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['blood_group']); ?></td>
                            <td>
                                <button onclick="window.location.href='editPatients.php?id=<?php echo $row['patient_id']; ?>'">Edit</button><br><br>
                                <button onclick="if(confirm('Are you sure you want to delete this patient?')) window.location.href='patientProfile.php?id=<?php echo $row['patient_id']; ?>'">Delete</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No patients found.</p>
        <?php endif; ?>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>
