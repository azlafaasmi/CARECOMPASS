<?php
require_once('../Connection.php');

// Check if patient ID is provided in the URL
if (isset($_GET['id'])) {
    $patient_id = $_GET['id'];

    // Fetch patient data based on the patient ID
    $query = "SELECT * FROM patients WHERE patient_id = '$patient_id'";
    $result = mysqli_query($conp, $query);

    if ($result) {
        $patient = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Error fetching patient details.');</script>";
        exit;
    }
} else {
    echo "<script>alert('No patient ID provided.');</script>";
    exit;
}

// Handle form submission to update patient details
if (isset($_POST['update'])) {
    $NIC = mysqli_real_escape_string($conp, $_POST['NIC']);
    $patient_name = mysqli_real_escape_string($conp, $_POST['patient_name']);
    $patient_age = mysqli_real_escape_string($conp, $_POST['patient_age']);
    $patient_gender = mysqli_real_escape_string($conp, $_POST['patient_gender']);
    $dob = mysqli_real_escape_string($conp, $_POST['dob']);
    $cont_no = mysqli_real_escape_string($conp, $_POST['cont_no']);
    $email = mysqli_real_escape_string($conp, $_POST['email']);
    $blood_group = mysqli_real_escape_string($conp, $_POST['blood_group']);

    // Update patient details in the database
    $update_query = "UPDATE patients SET NIC = '$NIC', patient_name = '$patient_name', patient_age = '$patient_age', patient_gender = '$patient_gender', dob = '$dob', cont_no = '$cont_no', email = '$email', blood_group = '$blood_group' WHERE patient_id = '$patient_id'";

    if (mysqli_query($conp, $update_query)) {
        echo "<script>alert('Patient details updated successfully!');</script>";
        echo "<script>window.location.href='managepatientList.php';</script>";
        exit; // Ensure the script stops executing after the redirect
    } else {
        echo "<script>alert('Error updating patient details.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') ;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            width: 100%;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            width: 100%;
            bottom: 0;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            color:black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 3px solid gray;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid gray;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: rgb(129, 129, 129);
            color: white;
            cursor: pointer;
        }

        button:hover {
            background-color: rgb(5, 6, 5);
        }
    </style>
</head>
<body>

<header>
    <h1>Edit Patient Details</h1>
</header>

<div class="container">
    <h2>Edit Patient: <?php echo htmlspecialchars($patient['patient_name']); ?></h2>

    <form method="POST">
        <label for="NIC">NIC</label>
        <input type="text" id="NIC" name="NIC" value="<?php echo htmlspecialchars($patient['NIC']); ?>" required>

        <label for="patient_name">Patient Name</label>
        <input type="text" id="patient_name" name="patient_name" value="<?php echo htmlspecialchars($patient['patient_name']); ?>" required>

        <label for="patient_age">Patient Age</label>
        <input type="number" id="patient_age" name="patient_age" value="<?php echo htmlspecialchars($patient['patient_age']); ?>" required>

        <label for="patient_gender">Gender</label>
        <select id="patient_gender" name="patient_gender" required>
            <option value="male" <?php echo ($patient['patient_gender'] == 'male') ? 'selected' : ''; ?>>Male</option>
            <option value="female" <?php echo ($patient['patient_gender'] == 'female') ? 'selected' : ''; ?>>Female</option>
            <option value="other" <?php echo ($patient['patient_gender'] == 'other') ? 'selected' : ''; ?>>Other</option>
        </select>

        <label for="dob">Date of Birth</label>
        <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($patient['dob']); ?>" required>

        <label for="cont_no">Contact Number</label>
        <input type="text" id="cont_no" name="cont_no" value="<?php echo htmlspecialchars($patient['cont_no']); ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($patient['email']); ?>" required>

        <label for="blood_group">Blood Group</label>
        <input type="text" id="blood_group" name="blood_group" value="<?php echo htmlspecialchars($patient['blood_group']); ?>" required>

        <button type="submit" name="update">Update Patient</button>
    </form>
</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
</footer>

</body>
</html>
