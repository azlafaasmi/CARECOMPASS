<?php
require_once('../Connection.php');

// Fetch appointments from the database
$query = "SELECT * FROM appointments";
$result = mysqli_query($conp, $query);

if (!$result) {
    echo "<script>alert('Error fetching appointments.');</script>";
}

// Delete appointment if delete_id is set
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = "DELETE FROM appointments WHERE appointment_id = '$delete_id'";

    if (mysqli_query($conp, $delete_query)) {
        echo "<script>alert('Appointment deleted successfully.');</script>";
        header("Location: manageAppointments.php"); // Redirect to avoid resubmission
        exit;
    } else {
        echo "<script>alert('Error deleting appointment.');</script>";
    }
}

// Update appointment if the update form is submitted
if (isset($_POST['update'])) {
    $appointment_id = $_POST['appointment_id'];
    $patient_id = mysqli_real_escape_string($conp, $_POST['patient_id']);
    $doctor_name = mysqli_real_escape_string($conp, $_POST['doctor_name']);
    $appointment_date = mysqli_real_escape_string($conp, $_POST['appointment_date']);
    $appointment_time = mysqli_real_escape_string($conp, $_POST['appointment_time']);
    $slot = mysqli_real_escape_string($conp, $_POST['slot']);
    $status = mysqli_real_escape_string($conp, $_POST['status']);

    // Update appointment details
    $update_query = "UPDATE appointments SET patient_id = '$patient_id', doctor_name = '$doctor_name', appointment_date = '$appointment_date', appointment_time = '$appointment_time', slot = '$slot', status = '$status' WHERE appointment_id = '$appointment_id'";

    if (mysqli_query($conp, $update_query)) {
        echo "<script>alert('Appointment updated successfully.');</script>";
        header("Location: manageAppointments.php"); // Redirect to avoid resubmission
        exit;
    } else {
        echo "<script>alert('Error updating appointment.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Appointments</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif');
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            width: 100%;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            width: 100%;
            bottom: 0;
        }

        /* Container and Table Styles */
        .container {
            width: 80%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            color: black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 3px solid gray;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 2px solid gray;
        }

        th, td {
            padding: 12px;
            text-align: center;
            color: black;
        }

        /* Button Styles */
        button {
            background-color: rgb(129, 129, 129);
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: rgb(5, 6, 5);
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage All Appointments</h1>
    </header>

    <div class="container">
        <h2>Appointments List</h2>

        <!-- Display Appointment List -->
        <table border="1" cellpadding="10">
            <thead>
                <tr>
                    <th>Appointment ID</th>
                    <th>Patient ID</th>
                    <th>Doctor Name</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Slot</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['appointment_id']; ?></td>
                        <td><?php echo $row['patient_id']; ?></td>
                        <td><?php echo $row['doctor_name']; ?></td>
                        <td><?php echo $row['appointment_date']; ?></td>
                        <td><?php echo $row['appointment_time']; ?></td>
                        <td><?php echo $row['slot']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td>
                            <button onclick="window.location.href='editAppointments.php?id=<?php echo $row['appointment_id']; ?>'">Edit</button>
                            <br> <br>
                            <button onclick="if(confirm('Are you sure you want to delete this appointment?')) window.location.href='manageAppointments.php?delete_id=<?php echo $row['appointment_id']; ?>'">Delete</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>
