<?php
require_once('../Connection.php'); 

if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conp, $_POST['username']);
    $email = mysqli_real_escape_string($conp, $_POST['email']);
    $password = mysqli_real_escape_string($conp, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conp, $_POST['confirm_password']);

    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match');</script>";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO admins (user_name, email, password) 
                  VALUES ('{$username}', '{$email}', '{$hashed_password}')";
        
        if (mysqli_query($conp, $query)) {
            echo "<script>alert('Admin Registered successfully!');</script>";
            echo "<script>window.location.href='../Users/Login.php';</script>";

        } else {
            echo "<script>alert('Error registering record . Please try again. ');</script>";
            echo "<script>window.location.href='adminRegistration.php';</script>";

        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') ;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }
        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }
        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }
        .container {
            width: 40%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border: 1px solid gray;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            color: black;

        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: black;

        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid gray;
            border-radius: 5px;
        }
        button {
            background-color: rgb(126, 126, 126);
            color: white;
            padding: 12px 20px;
            border: 1px solid black;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: rgb(7, 7, 7);
        }
        .form-footer {
            text-align: center;
            color: black;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Registration</h1>
    </header>

    <div class="container">
        <form action="adminRegistration.php" method="POST">
            <h2>Register as Admin</h2>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>

            <button type="submit" name="submit">Register</button>
        </form>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>
