<?php
session_start();
require_once('../Connection.php'); // Ensure database connection is included

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $appointment_id = mysqli_real_escape_string($conp, $_GET['id']);
    
    // Fetch appointment details from the database based on the provided appointment ID
    $query = "SELECT * FROM appointments WHERE appointment_id = '$appointment_id'";
    $result = $conp->query($query);
    
    // Check if the appointment exists
    if ($result->num_rows > 0) {
        $appointment = $result->fetch_assoc();
    } else {
        echo "<script>alert('Appointment not found!');</script>";
        echo "<script>window.location.href='manageAppointments.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('No appointment ID provided.');</script>";
    echo "<script>window.location.href='manageAppointments.php';</script>";
    exit;
}

// Handle the form submission to update the appointment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture and sanitize input
    $patient_id = mysqli_real_escape_string($conp, $_POST['patient_id']);
    $doctor_name = mysqli_real_escape_string($conp, $_POST['doctor_name']);
    $appointment_date = mysqli_real_escape_string($conp, $_POST['appointment_date']);
    $appointment_time = mysqli_real_escape_string($conp, $_POST['appointment_time']);
    $status = mysqli_real_escape_string($conp, $_POST['status']);

    // Update appointment details in the database
    $updateQuery = "UPDATE appointments SET patient_id = '$patient_id', doctor_name = '$doctor_name', 
                    appointment_date = '$appointment_date', appointment_time = '$appointment_time', 
                    status = '$status' WHERE appointment_id = '$appointment_id'";

    if ($conp->query($updateQuery)) {
        echo "<script>alert('Appointment updated successfully!');</script>";
        echo "<script>window.location.href='manageAppointments.php';</script>";
    } else {
        echo "<script>alert('Error updating appointment. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') ;
            background-size: cover;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px;
            background-color: rgba(151, 153, 155, 0.8);
            color: black;
            width: 100%;
            font-size: 26px;
            font-weight: bold;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border: 2px solid black;
        }

        h2 {
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        select {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid gray;
            border-radius: 5px;
        }

        button {
            background-color: rgb(129, 129, 129);
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: rgb(5, 6, 5);
        }

        footer {
            display: flex;
            justify-content: center;
            padding: 12px;
            background-color: rgba(151, 153, 155, 0.8);
            color: black;
            width: 100%;
            font-size: 18px;
            font-weight: bold;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <header>
        <h3>Edit Appointment</h3>
    </header>

    <div class="container">
        <!-- Edit Appointment Form -->
        <h2>Edit Appointment Details</h2>
        <form action="editAppointments.php?id=<?php echo $appointment_id; ?>" method="POST">
            <label for="patient_id">Patient ID</label>
            <input type="text" id="patient_id" name="patient_id" value="<?php echo htmlspecialchars($appointment['patient_id']); ?>" required>

            <label for="doctor_name">Doctor Name</label>
            <input type="text" id="doctor_name" name="doctor_name" value="<?php echo htmlspecialchars($appointment['doctor_name']); ?>" required>

            <label for="appointment_date">Appointment Date</label>
            <input type="date" id="appointment_date" name="appointment_date" value="<?php echo htmlspecialchars($appointment['appointment_date']); ?>" required>

            <label for="appointment_time">Appointment Time</label>
            <select id="appointment_time" name="appointment_time" required>
                <option value="09:00 - 09:10" <?php echo ($appointment['appointment_time'] == '09:00 - 09:10') ? 'selected' : ''; ?>>09:00 - 09:10</option>
                <option value="09:10 - 09:20" <?php echo ($appointment['appointment_time'] == '09:10 - 09:20') ? 'selected' : ''; ?>>09:10 - 09:20</option>
                <option value="09:20 - 09:30" <?php echo ($appointment['appointment_time'] == '09:20 - 09:30') ? 'selected' : ''; ?>>09:20 - 09:30</option>
                <option value="09:30 - 09:40" <?php echo ($appointment['appointment_time'] == '09:30 - 09:40') ? 'selected' : ''; ?>>09:30 - 09:40</option>
                <option value="09:40 - 09:50" <?php echo ($appointment['appointment_time'] == '09:40 - 09:50') ? 'selected' : ''; ?>>09:40 - 09:50</option>
                <!-- Add more time slots as needed -->
            </select>

            <label for="status">Status</label>
            <select id="status" name="status" required>
                <option value="Scheduled" <?php echo ($appointment['status'] == 'Scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                <option value="Completed" <?php echo ($appointment['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                <option value="Cancelled" <?php echo ($appointment['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                <option value="Rescheduled" <?php echo ($appointment['status'] == 'Rescheduled') ? 'selected' : ''; ?>>Rescheduled</option>
            </select>

            <button type="submit">Update Appointment</button>
        </form>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>