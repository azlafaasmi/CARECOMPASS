<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') ;
            margin: 0;
            padding: 0;
            background-size: cover;
        }

        header {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(104, 106, 108, 0.9);
            color: black;
            width: 100%;
        }

        header h2 {
            color: black;

        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.9);
            color: black;
            width: 100%;
        }

        .container {
            width: 60%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            border: 2px solid black;
        }
        .container p{
            color:green;
        }
        .error {
            color: red;
            font-weight: bold;
            font-size: 1.1rem;
            margin-top: 10px;
        }

        h2 {
            text-align: center;
            font-size: 1.8rem;
            color: #333;
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 10px 0 5px;
            font-size: 1rem;
            font-weight: bold;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        select,
        textarea {
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid black;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        textarea:focus,
        select:focus {
            border-color: rgb(120, 122, 123);
            box-shadow: 0 0 10px rgba(26, 26, 26, 0.5);
            outline: none;
            border: 1px solid #ccc;
        }

        button {
            background-color: rgb(113, 114, 115);
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            border: 1px solid black;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: rgb(0, 0, 0);
        }

        table {
            width: 100%;
            margin-bottom: 30px;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
            border-radius: 8px;
        }

        th, td {
            padding: 12px;
            text-align: center;
            color: black;
            
        }

        th {
            background-color: rgb(137, 139, 141);
            color: black;
            font-size: 1.1rem;
        }

        tr:nth-child(even) {
            background-color: rbg(206, 205, 205);
        }

        tr:hover {
            background-color: rbg(121, 120, 120);
        }

        .form-footer {
            text-align: center;
            margin-top: 20px;
        }

    </style>
</head>
<body>

<header>
    <h2>Service Management</h2>
</header>

<div class="container">

<?php
require_once('../Connection.php'); // Ensure the database connection is properly established
session_start();

// Display services
$sql = "SELECT service_id, name, description, price FROM services";
$result = $conp->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Available Services</h2>";
    echo "<table><tr><th>Service ID</th><th>Name</th><th>Description</th><th>Price</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row['service_id'] . "</td><td>" . $row['name'] . "</td><td>" . $row['description'] . "</td><td>" . $row['price'] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p>No services available.</p>";
}

// Add new service
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $insertSql = "INSERT INTO services (name, description, price) VALUES (?,?,?)";
    $stmt = $conp->prepare($insertSql);
    $stmt->bind_param("ssd", $name, $description, $price);

    if ($stmt->execute()) {
        echo "<p>New service added successfully.</p>";
    } else {
        echo "<p>Error adding service: " . $conp->error . "</p>";
    }
}

// Close connection
$conp->close();
?>

    <h2>Add New Service</h2>
    <form method="POST" action="">
        <label for="name">Service Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea>

        <label for="price">Price:</label>
        <input type="number" id="price" name="price" step="0.01" required>

        <button type="submit">Add Service</button>
    </form>

</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | Service Management System | All rights reserved.</p>
</footer>

</body>
</html>
