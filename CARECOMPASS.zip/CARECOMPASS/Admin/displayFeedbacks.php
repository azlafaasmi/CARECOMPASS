<?php
session_start();
require_once('../Connection.php');

// Fetch feedback from the database
$sql = "SELECT id, name, email, feedback, created_at FROM feedback ORDER BY created_at DESC";
$result = mysqli_query($conp, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') ;
            background-size: cover;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            font-weight: bold;
        }

        .container {
            max-width: 900px;
            margin: 80px auto;
            background: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: 2px solid gray;
        }

        h1 {
            text-align: center;
            color: black;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table th, table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
            border: 2px solid gray;
        }

        table th {
            background-color:rbg;
            font-weight: bold;
            border: 2px solid gray;
        }

        table tr:nth-child(even) {
            background-color:rbg;
            border: 2px solid gray;
        }

        footer {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            font-weight: bold;
        }

        .no-feedback {
            text-align: center;
            color: #d9534f;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Feedback List</h1>
    </header>

    <div class="container">
        <h1>Submitted Feedbacks</h1>
        <?php if (mysqli_num_rows($result) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Feedback</th>
                        <th>Date Submitted</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $i++; ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['feedback']); ?></td>
                            <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-feedback">No feedback available at the moment.</p>
        <?php endif; ?>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>
