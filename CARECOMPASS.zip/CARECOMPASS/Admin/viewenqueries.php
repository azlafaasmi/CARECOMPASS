<?php
require_once('../Connection.php');  

// Fetch enquiries from the database
$query = "SELECT * FROM enquiry";
$result = mysqli_query($conp, $query);

// Check for any errors in the query
if (!$result) {
    die("Query failed: " . mysqli_error($conp));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Enquiries</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 2px solid black;

        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;

        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 12px;
            text-align: center;
            color: black;
        }

        th {
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
        }

        tr:nth-child(even) {
            background-color:rgb(182, 182, 182);
        }

        tr:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>

<header>
<h2>Enquiries List</h2>
</header>

<div class="container">

    <!-- Enquiry Table -->
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Loop through and display each enquiry
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                echo "<td>" . htmlspecialchars($row['message']) . "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
</footer>

</body>
</html>

<?php
// Close the database connection
mysqli_close($conp);
?>
