<?php
require_once('../Connection.php');  
$query = "SELECT * FROM queries ORDER BY submitted_at DESC";  
$result = mysqli_query($conp, $query); 

if (!$result) {
    die("Database query failed: " . mysqli_error($conp));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queries Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            border:2px solid black;
            background-color: rbg(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 2px solid black;
        }

        th, td {
            padding: 12px;
            text-align: center;
            color: black;
        }

        th {
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
        }

        input[type="text"] {
            width: 80%;
            padding: 5px;
            border: 1px solid black;
            border-radius: 5px;
        }

        button {
            background-color: rgb(129, 129, 129);
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: rgb(5, 6, 5);
        }
    </style>

    <script>
        function confirmDelete(id) {
            if (confirm("Are you sure you want to delete this query?")) {
                window.location.href = 'delete_query.php?id=' + id;
            }
        }

        function sendReply(id) {
            let replyText = document.getElementById('reply_' + id).value;
            if (replyText.trim() === "") {
                alert("Reply cannot be empty.");
                return;
            }

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "send_reply.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    alert("Reply successfully sent!");
                    document.getElementById('response_' + id).innerText = replyText;
                    document.getElementById('reply_' + id).value = "";
                } else if (xhr.readyState === 4) {
                    alert("Error sending reply: " + xhr.statusText);
                }
            };

            xhr.send("id=" + id + "&response=" + encodeURIComponent(replyText));
        }
    </script>
</head>
<body>

<header>
    <h2>Queries Management</h2>
</header>

<div class="container">
    <?php if (mysqli_num_rows($result) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Query ID</th>
                    <th>Patient ID</th>
                    <th>Response</th>
                    <th>Message</th>
                    <th>Submitted At</th>
                    <th>Reply</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['query_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['patient_id']); ?></td>
                        <td id="response_<?php echo $row['query_id']; ?>">
                            <?php echo ucfirst(htmlspecialchars($row['response'])); ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['message']); ?></td>
                        <td><?php echo htmlspecialchars($row['submitted_at']); ?></td>
                        <td>
                            <input type="text" id="reply_<?php echo $row['query_id']; ?>" placeholder="Type your reply...">
                            <button onclick="sendReply(<?php echo $row['query_id']; ?>)">Send Reply</button>
                        </td>
                        <td>
                            <button onclick="confirmDelete(<?php echo $row['query_id']; ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No queries found.</p>
    <?php endif; ?>
</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
</footer>

</body>
</html>

<?php
// Close the database connection after use
mysqli_close($conp);
?>
