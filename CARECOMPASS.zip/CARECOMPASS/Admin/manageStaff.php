<?php
session_start();
require_once('../Connection.php'); // Ensure database connection is included

// Handle staff deletion
if (isset($_POST['delete'])) {
    // Validate staff_id
    if (isset($_POST['staff_id']) && !empty($_POST['staff_id'])) {
        $staffIdToDelete = mysqli_real_escape_string($conp, $_POST['staff_id']);
        
        // Prepare the delete query using prepared statements
        $deleteQuery = $conp->prepare("DELETE FROM staff WHERE staff_id = ?");
        $deleteQuery->bind_param("i", $staffIdToDelete);
        
        // Execute the query
        if ($deleteQuery->execute()) {
            echo "<script>alert('Staff deleted successfully!');</script>";
            echo "<script>window.location.href='manageStaff.php';</script>";
        } else {
            echo "<script>alert('Error deleting staff. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Invalid staff ID!');</script>";
    }
}

// Fetch all staff from the database
$sqlStaff = "SELECT staff_id, nic, full_name, speciality, qualifications, role, years_of_experience, isAvailable, email, cont_no FROM staff";
$resultStaff = $conp->query($sqlStaff);

$staff = [];
if ($resultStaff->num_rows > 0) {
    while ($row = $resultStaff->fetch_assoc()) {
        $staff[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Staff</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') no-repeat center center fixed;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            width: 100%;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            width: 100%;
            bottom: 0;
        }

        /* Container and Table Styles */
        .container {
            width: 100%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            color: black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 3px solid black;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 20%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 2px solid black;
        }

        th, td {
            padding: 12px;
            text-align: center;
            color: black;
        }

        /* Button Styles */
        button {
            background-color: rgb(129, 129, 129);
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: rgb(5, 6, 5);
        }
    </style>
</head>
<body>

    <header>
        <h1>Manage Staff</h1>
    </header>

    <div class="container">
        <!-- Staff List Table -->
        <h2>Staff List</h2>
        <table>
            <thead>
                <tr>
                    <th>Staff ID</th>
                    <th>NIC</th>
                    <th>Full Name</th>
                    <th>Speciality</th>
                    <th>Qualifications</th>
                    <th>Role</th>
                    <th>Years of Experience</th>
                    <th>Availability</th>
                    <th>Email</th>
                    <th>Contact Number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($staff) > 0): ?>
                    <?php foreach ($staff as $member): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($member['staff_id']); ?></td>
                            <td><?php echo htmlspecialchars($member['nic']); ?></td>
                            <td><?php echo htmlspecialchars($member['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($member['speciality']); ?></td>
                            <td><?php echo htmlspecialchars($member['qualifications']); ?></td>
                            <td><?php echo htmlspecialchars($member['role']); ?></td>
                            <td><?php echo htmlspecialchars($member['years_of_experience']); ?></td>
                            <td><?php echo $member['isAvailable'] ? 'Available' : 'Not Available'; ?></td>
                            <td><?php echo htmlspecialchars($member['email']); ?></td>
                            <td><?php echo htmlspecialchars($member['cont_no']); ?></td>
                            <td>
                                <!-- Edit Button -->
                                <button onclick="window.location.href='editStaffs.php?id=<?php echo $member['staff_id']; ?>'">Edit</button>
                                <br><br>
                                <!-- Delete Button with confirmation -->
                                <form method="POST" onsubmit="return confirm('Are you sure you want to delete this staff?');">
                                    <input type="hidden" name="staff_id" value="<?php echo $member['staff_id']; ?>">
                                    <button type="submit" name="delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11">No staff found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>

</body>
</html>
