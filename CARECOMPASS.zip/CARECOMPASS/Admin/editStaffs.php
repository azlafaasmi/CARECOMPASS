<?php
require_once('../Connection.php'); // Include your DB connection file

// Check if the staff ID is passed in the URL
if (isset($_GET['id'])) {
    $staffId = mysqli_real_escape_string($conp, $_GET['id']); // Sanitize input

    // Query to fetch staff details based on the staff_id
    $query = "SELECT * FROM staff WHERE staff_id = '$staffId'";
    $result = mysqli_query($conp, $query);

    // Fetch the staff data if found
    if ($result && mysqli_num_rows($result) > 0) {
        $staffData = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Staff not found.'); window.location.href='manageStaff.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('Invalid request.'); window.location.href='manageStaff.php';</script>";
    exit;
}

// Handle form submission to update staff details
if (isset($_POST['update'])) {
    $staffId = mysqli_real_escape_string($conp, $_POST['staff_id']);
    $full_name = mysqli_real_escape_string($conp, $_POST['full_name']);
    $nic = mysqli_real_escape_string($conp, $_POST['nic']);
    $speciality = mysqli_real_escape_string($conp, $_POST['speciality']);
    $qualifications = mysqli_real_escape_string($conp, $_POST['qualifications']);
    $role = mysqli_real_escape_string($conp, $_POST['role']);
    $years_of_experience = mysqli_real_escape_string($conp, $_POST['years_of_experience']);
    $isAvailable = mysqli_real_escape_string($conp, $_POST['isAvailable']);
    $email = mysqli_real_escape_string($conp, $_POST['email']);
    $cont_no = mysqli_real_escape_string($conp, $_POST['cont_no']);

    // Update query to modify staff details
    $updateQuery = "UPDATE staff SET 
        full_name = '$full_name', 
        NIC = '$nic', 
        speciality = '$speciality', 
        qualifications = '$qualifications', 
        role = '$role', 
        years_of_experience = '$years_of_experience', 
        isAvailable = '$isAvailable', 
        email = '$email', 
        cont_no = '$cont_no' 
        WHERE staff_id = '$staffId'";

    if (mysqli_query($conp, $updateQuery)) {
        echo "<script>alert('Staff details updated successfully.'); window.location.href='manageStaff.php';</script>";
    } else {
        echo "<script>alert('Error updating staff details.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Staff</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif');
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
            width: 100%;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            width: 100%;
            bottom: 0;
        }

        /* Container and Table Styles */
        .container {
            width: 50%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            color:black;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 3px solid gray;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        /* Form Input Styles */
        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
        }

        input {
            width: 90%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid black;
            border-radius: 5px;
        }

        button {
            background-color: rgb(129, 129, 129);
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 90%;
        }

        button:hover {
            background-color: rgb(5, 6, 5);
        }
    </style>
</head>
<body>

    <header>
        <h1>Edit Staff Details</h1>
    </header>

    <div class="container">
        <!-- You can replace the following line with the actual staff name -->
        <h2>Edit Staff: <?php echo htmlspecialchars($staffData['full_name']); ?></h2>

        <form method="POST">
            <input type="hidden" name="staff_id" value="<?php echo htmlspecialchars($staffData['staff_id']); ?>">

            <label for="full_name">Full Name</label>
            <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($staffData['full_name']); ?>" required>

            <label for="nic">NIC</label>
            <input type="text" id="nic" name="nic" value="<?php echo htmlspecialchars($staffData['NIC']); ?>" required>

            <label for="speciality">Speciality</label>
            <input type="text" id="speciality" name="speciality" value="<?php echo htmlspecialchars($staffData['speciality']); ?>" required>

            <label for="qualifications">Qualifications</label>
            <input type="text" id="qualifications" name="qualifications" value="<?php echo htmlspecialchars($staffData['qualifications']); ?>" required>

            <label for="role">Role</label>
            <input type="text" id="role" name="role" value="<?php echo htmlspecialchars($staffData['role']); ?>" required>

            <label for="years_of_experience">Years of Experience</label>
            <input type="number" id="years_of_experience" name="years_of_experience" value="<?php echo htmlspecialchars($staffData['years_of_experience']); ?>" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($staffData['email']); ?>" required>

            <label for="cont_no">Contact Number</label>
            <input type="text" id="cont_no" name="cont_no" value="<?php echo htmlspecialchars($staffData['cont_no']); ?>" required>
            
            <label for="isAvailable">Available</label>
            <input type="checkbox" id="isAvailable" name="isAvailable" <?php echo $staffData['isAvailable'] ? 'checked' : ''; ?>>

            <button type="submit" name="update">Update Staff</button>
        </form>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>

</body>
</html>
