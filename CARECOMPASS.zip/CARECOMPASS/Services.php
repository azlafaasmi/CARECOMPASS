<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('./src/background.avif') ;
            background-size: cover;
            color: rgb(124, 127, 130);
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: center;
            padding: 15px 20px;
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
            text-align: center;
        }

        footer {
            text-align: center;
            padding: 15px 20px;
            background-color: rgba(79, 83, 86, 0.8);
            color: black;
            bottom: 0;
            width: 100%;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: rbg(255, 255, 255, 0.9);
            padding: 20px;
            border: 2px solid black;
            border-radius: 10px;
            color: black;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            font-weight: bold;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        #search-bar {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 2px solid gray;
            border-radius: 5px;
            font-size: 16px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: rgba(128, 132, 135, 0.8);
            color: black;
        }
    </style>
</head>
<body>

<header>
    <h1>Service</h1>
</header>

<div class="container">
    <h2>Available Services</h2>

    <!-- Search Bar -->
    <input type="text" id="search-bar" onkeyup="filterServices()" placeholder="Search services by name...">

    <?php
    require_once('./Connection.php');
    session_start();

    // Fetch services
    $sql = "SELECT service_id, name, description, price FROM services";
    $result = $conp->query($sql);

    if ($result->num_rows > 0) {
        echo "<table id='services-table'><tr><th>Service ID</th><th>Name</th><th>Description</th><th>Price</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row['service_id'] . "</td><td>" . $row['name'] . "</td><td>" . $row['description'] . "</td><td>" . $row['price'] . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No services available.</p>";
    }
    // Close connection
    $conp->close();
    ?>

</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | Service Management System | All rights reserved.</p>
</footer>

<script>
    function filterServices() {
        let input = document.getElementById('search-bar').value.toLowerCase();
        let table = document.getElementById('services-table');
        let rows = table.getElementsByTagName('tr');

        for (let i = 1; i < rows.length; i++) {
            let nameCell = rows[i].getElementsByTagName('td')[1]; // Second column (service name)
            if (nameCell) {
                let nameText = nameCell.textContent || nameCell.innerText;
                if (nameText.toLowerCase().indexOf(input) > -1) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        }
    }
</script>

</body>
</html>
