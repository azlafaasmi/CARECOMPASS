<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "carecompass_db";
$conp = mysqli_connect($host, $user, $password, $database);

if(mysqli_connect_error()){
    die('Database connection failed'.mysqli_connection_errno());
}
?>