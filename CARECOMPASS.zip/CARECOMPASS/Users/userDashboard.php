<?php
session_start();
require_once('../Connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('../src/background.avif') ;
            background-size: cover;
            color: #333;
            margin: 0;
        }

        header {
            display: flex;
            justify-content: center; 
            padding: 10px 20px; 
            background-color: rgba(151, 153, 155, 0.8);
            color: white;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            font-size: 24px; 
            font-weight: bold;
        }

        .container {
            max-width: 1000px; 
            margin: 40px auto; /* Reduced margin-top to reduce gap */
            background: rbg(255, 255, 255, 0.9); /* Fixed rgba issue */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: 2px solid black;
            width: 40%;
        }

        h1 {
            color: black;
        }

        .section {
            margin-top: 30px;
            padding: 20px;
            background-color: rbg(255, 255, 255, 0.7); /* Fixed rgba issue */
            border: 1px solid black;
            border-radius: 12px;
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .section h2 {
            margin-bottom: 20px;
            color: rgb(2, 2, 3);
        }

        .section p {
            margin-bottom: 20px;
        }

        .section a {
            text-decoration: none;
            color: #fff;
            background-color: rgb(133, 135, 137);
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.3s;
        }

        .section a:hover {
            background-color: rgb(13, 13, 13);
            transform: scale(1.05);
        }

        footer {
            display: flex;
            justify-content: center; 
            padding: 10px 20px; 
            background-color: rgba(151, 153, 155, 0.8);
            color: black;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            font-size: 24px; 
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to the System</h1>
    </header>

    <div class="container">
        <!-- Admin Section -->
        <div class="section">
            <h2>Administrators</h2>
            <a href="../Admin/adminRegistration.php">Admin Registration</a>
        </div> 

        <!-- Staff Section -->
        <div class="section">
            <h2>Hospital Staff</h2>
            <a href="../Staff/staffRegistration.php">Staff Registration</a>
        </div>

        <!-- Doctors Section -->
        <div class="section">
            <h2>Hospital Doctors</h2>
            <a href="../Staff/doctorRegistration.php">Doctors Registration</a>
        </div>

        <!-- Patients Section -->
        <div class="section">
            <h2>Patients</h2>
            <a href="../Patient/patientRegistration.php">Patients Registration</a>
        </div>

        <!-- User Login Section -->
        <div class="section">
            <h2>User Login</h2>
            <a href="../Users/Login.php">Login</a>
        </div>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
    </footer>
</body>
</html>
