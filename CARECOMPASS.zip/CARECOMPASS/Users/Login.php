<?php
require_once('../Connection.php');
session_start();

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conp, $_POST['user_name']);
    $password = mysqli_real_escape_string($conp, $_POST['user_password']);
    $role = mysqli_real_escape_string($conp, $_POST['role']);

    $user_query = "SELECT * FROM users WHERE user_name = '{$username}' AND user_password='{$password}' AND role = '{$role}' LIMIT 1";
    $result = mysqli_query($conp, $user_query);

    if ($result) {
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);

            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['username'] = $row['user_name'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['loggedin'] = true;
            $_SESSION['success_message'] = "Login successful! Welcome, " . $row['user_name']; // Success message

            switch ($role) {
                case 'Admin':
                    header("Location: ../Admin/adminDashboard.php");
                    break;
                case 'Doctor':
                    header("Location: ../Staff/doctorDashboard.php");
                    break;
                case 'Patient':
                    header("Location: ../Patient/patientPortal.php");
                    break;
                case 'Receptionist':
                    header("Location: ../Staff/receptionistDashboard.php");
                    break;
                case 'Nurse':
                    header("Location: ../Staff/nurseDashboard.php");
                    break;
                case 'Lab Technician':
                    header("Location: ../Staff/labTechnicianDashboard.php");
                    break;
            }
            exit();
        } else {
            $_SESSION['error_message'] = "Invalid username, password, or role. Please try again."; // Error message
        }
    } else {
        $_SESSION['error_message'] = "An error occurred while processing your request. Please try again."; // General error message
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Login</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: url('../src/background.avif') no-repeat center center fixed;
      background-size: cover;
      color: rgb(124, 127, 130);
      margin: 0;
    }

    header {
      display: flex;
      justify-content: center;
      padding: 15px 20px;
      background-color: rgba(128, 132, 135, 0.8);
      color: white;
    }

    footer {
      text-align: center;
      padding: 15px;
      background-color: rgba(79, 83, 86, 0.8);
      color: black;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

    .container {
      background-color: rgba(217, 217, 217, 0.8);
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 500px;
      margin: 30px auto;
      border: 2px solid gray;
    }

    h1 {
      text-align: center;
      color: black;
    }

    form {
      display: flex;
      flex-direction: column;
      color: black;
    }

    input[type="text"], input[type="password"], select {
      margin-bottom: 15px;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 14px;
      border: 2px solid gray;
    }

    button {
      padding: 10px;
      background: rgb(87, 89, 90);
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }

    button:hover {
      background: rgb(6, 6, 6);
    }

    .message {
      padding: 10px;
      border-radius: 5px;
      margin-bottom: 15px;
    }

    .success {
      background-color: #d4edda;
      color: #155724;
    }

    .error {
      background-color: #f8d7da;
      color: #721c24;
    }
  </style>
</head>
<body>

<header>
  <h1>Welcome to the System</h1>
</header>

<div class="container">
  <h1>User Login</h1>
  
  <?php
  if (isset($_SESSION['success_message'])) {
      echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
      unset($_SESSION['success_message']); // Clear the message after displaying it
  }

  if (isset($_SESSION['error_message'])) {
      echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
      unset($_SESSION['error_message']); // Clear the message after displaying it
  }
  ?>
  
  <form action="Login.php" method="POST">
    <label for="user_name">UserName</label>
    <input type="text" name="user_name" id="user_name" required>
    <label for="user_password">UserPassword</label>
    <input type="password" name="user_password" id="user_password" required>
    <label for="role">Role</label>
    <select name="role" id="role" required>
      <option value="Admin">Administrator</option>
      <option value="Doctor">Doctor</option>
      <option value="Receptionist">Receptionist</option>
      <option value="Nurse">Nurse</option>
      <option value="Lab Technician">Lab Technician</option>
      <option value="Patient">Patient</option>
    </select><br>
    <button type="submit" name="login">Login</button>
  </form>
</div>

<footer>
  <p>&copy; <?php echo date("Y"); ?> CARECOMPASS Hospital | All rights reserved.</p>
</footer>
</body>
</html>
