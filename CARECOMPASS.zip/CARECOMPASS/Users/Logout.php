<?php
session_start();

if (isset($_SESSION['userid'])) {
    session_unset();
    session_destroy();
    

    header('Location: Login.php?logout=success');
    exit;
} else {

    header('Location: Login.php');
    exit;
}
?>
